<?php 
include_once('header.php');
include_once('menu.php');
?>
<!-- page-title -->
    <div class="ttm-page-title-row">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-box ttm-textcolor-white">
              <div class="page-title-heading">
                <!-- Change title when detail is clicked --> 
                <h1 class="title title-ani">Trouve des<br> information rapide</h1>
              </div><!-- /.page-title-captions -->
              <div class="breadcrumb-wrapper">
                <span>
                  <a title="Homepage" href="index.html"><i class="ti ti-home"></i>&nbsp;&nbsp;Accueil</a>
                </span>
                <span class="ttm-bread-sep">&nbsp; | &nbsp;</span>
              </div>
            </div>
          </div><!-- /.col-md-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </div>
  <!-- page-title end-->
    <!--site-main start-->
    
      <!-- Politique -->
      <section class="ttm-row blog-text-section ttm-bgcolor-grey mt_120 res-991-mt-0 clearfix" style="margin-bottom: 0px !important;">
        <div class="container">
        <!-- row -->
          <div class="row">
            <div class="col-lg-12 col-md-12">
              <!-- section-title -->
              <div class="section-title style2 clearfix">
                <div class="title-header">
                  <h2 class="title politique" style="border-left: 4.2px green solid;">Resultat trouve</h2>
                </div>
              <hr>
              </div><!-- section-title end -->
            </div>
          </div>
        <!-- row end -->
        
        <!-- Getting data from mysql server -->
        <div class="row">
          <div class='displaydetail container-fluid'>
          <section class='container mt-3 mb-3'>
            <div class='row'>
          <?php
          if (isset($_GET['s'])) {
           $findsearch = $_GET['s'];
           $sql_query = "select * from tbl_news where title like '$findsearch%'";
           $res_s = mysqli_query($con, $sql_query);
           if (mysqli_num_rows($res_s)) {
           while($row_s=mysqli_fetch_assoc($res_s)){?>
             <div class="col-xs-12 col-sm-6 col-md-4 mb-3">
               <img src="<?php echo $row_s['image'];?>" width='350' height='300' style='border-radius: 5px;'>
             </div>
             <div class="col-xs-12 col-sm-6 col-md-8">
               <h2><?php echo $row_s['title'];?></h2>
               <p class="text-dark"><?php echo $row_s['publisher'];?></p>
               <button class="btn btn-danger"><a href="search.php?detail=<?php echo $row_s['displayid'];?>" class='text-white'>Lire la suite</a></button>
             </div>
                    
          <?php }}else{echo "<h2 class='text-center'>Oops nous sommes desole.</h2>";}}?>
        <!-- Start of the first politique news --> 
        <?php
        if (isset($_GET['detail'])) {
          $search = $_GET['detail'];
          $sql_query = "select * from tbl_news where displayid='$search'";
          $res_s = mysqli_query($con, $sql_query);
          if (mysqli_num_rows($res_s)) {
          while($row=mysqli_fetch_assoc($res_s)){?>
          <div class='col-xs-12 col-sm-8 col-md-6 col-lg-6 rightdetail'>
          <h3 style='font-size: 1.5rem;line-height:1.16667;color: #1e1e1e;font-weight: bold;'><?php echo $row['title'];?></h3>
          <p class='mt-2'>Par <?php echo $row['publisher'];?></p>
          <p><img src='images/watch.png' width='22' height='22' class='mr-1' style='position:relative;bottom:4px;'><?php echo $row['infodate'];?></p>
          <hr>
          <img src='<?php echo $row["image"];?>' style='width:100%;margin-bottom:8px;'>
          <p class='mt-2 text-justify'><?php echo $row['message'];?></p>
          
          </div>
          <div class='col-xs-12 col-sm-4 col-md-4 col-lg-4'>
          <div class='w-100'>
           <h4 class='ml-3'>Nos dernieres actualites</h4>
           <hr class='ml-3 mr-3'>
          </div>
          <div id='dataShow'>
          <script type='text/javascript'>
            
        messageGet = document.getElementById('dataShow');
             
        function Showmessage() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            messageGet.innerHTML = this.responseText;
            }
         };
        xhttp.open('POST', 'ajax/cultureShow.php', true);
        xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhttp.send(); 
      }
      //Showmessage()
      setInterval(function(){Showmessage()},1800);

            </script>
          </div>
          </div>
          </div>
          </section>
          </div>
          <br>
          <br>
            <?php }}}?>
          
       </div>
       <!-- End of politique -->
      </div>
      </section>
      <!--blog-text-section end-->

    </div>
    <!--site-main end-->

    <!-- Active link per page -->
    <script>
      element = document.getElementById('news');
      element.classList.add("active")
    </script>
    <!-- End of active link -->
  

    <?php 
    include_once('footer.php');
    ?>
