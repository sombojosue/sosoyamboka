<?php 
include_once('header.php');
include_once('menu.php');
?>


    <div id="rev_slider_4_1_wrapper" class="rev_slider_wrapper fullwidthbanner-container slide-overlay" data-alias="classic4export" data-source="gallery">
      <!-- START REVOLUTION SLIDER 5.4.8 auto mode -->
      <div id="rev_slider_4_1" class="rev_slider fullwidthabanner rev_slider_4_1_height" data-version="5.4.8.1">

        <ul>
          <!-- SLIDE  -->
          <li data-index="rs-11" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-thumb="images/slides/slider-mainbg-001.jpg"
            data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
            <!-- MAIN IMAGE -->
            <img src="images/slides/slider-mainbg-001.jpg" alt="" title="home-main-sliderbg01" width="1920" height="730" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
            <!-- LAYERS -->
            <!-- LAYER NR. 1 -->
            <div class="tp-caption ttm-textcolor-skincolor tp-resizeme" id="slide-1-layer-1" data-x="['left','left','center','center']" data-hoffset="['50','50','-628','-684']" data-y="['top','top','middle','middle']"
              data-voffset="['159','159','-116','46']" data-fontsize="['14','14','12','11']" data-fontweight="['600','600','700','700']" data-width="none" data-height="none" data-whitespace="nowrap" data-visibility="['on','on','off','off']"
              data-type="text" data-responsive_offset="on"
              data-frames='[{"delay":140,"speed":500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power0.easeIn"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
              data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"></div>

            <!-- LAYER NR. 2 -->
            <div class="tp-caption tp-resizeme" id="slide-1-layer-2" data-x="['left','left','center','center']" data-hoffset="['50','50','0','0']" data-y="['top','top','middle','middle']" data-voffset="['185','185','-107','-87']"
              data-fontsize="['60','60','50','40']" data-lineheight="['75','75','75','60']" data-fontweight="['700','700','700','700']" data-color="['rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)']" data-width="none"
              data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
              data-frames='[{"delay":380,"speed":800,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power0.easeIn"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
              data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">Toute nation a les <br>dirigeants qu'elle<br> mérite</div>

            <!-- LAYER NR. 3 -->
            <div class="tp-caption tp-resizeme" id="slide-1-layer-3" data-x="['left','left','center','center']" data-hoffset="['50','50','0','0']" data-y="['top','top','middle','middle']" data-voffset="['257','257','-46','-38']"
              data-fontsize="['60','60','50','40']" data-lineheight="['75','75','75','60']" data-fontweight="['700','700','700','700']" data-color="['rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)']" data-width="none"
              data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
              data-frames='[{"delay":540,"speed":800,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power0.easeIn"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
              data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"><strong
                class="ttm-textcolor-skincolor"></strong> </div>

            <!-- LAYER NR. 4 -->
            <div class="tp-caption tp-resizeme" id="slide-1-layer-4" data-x="['left','left','center','center']" data-hoffset="['50','50','-702','-702']" data-y="['top','top','middle','middle']" data-voffset="['350','350','247','247']"
              data-fontsize="['16','16','14','14']" data-lineheight="['26','26','24','24']" data-fontweight="['400','400','400','400']" data-color="['rgb(222,222,222)','rgb(222,222,222)','rgb(222,222,222)','rgb(222,222,222)']" data-width="none"
              data-height="none" data-whitespace="nowrap" data-visibility="['on','on','off','off']" data-type="text" data-responsive_offset="on"
              data-frames='[{"delay":830,"speed":500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power0.easeIn"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
              data-textAlign="['inherit','inherit','center','center']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"></div>

            <!-- LAYER NR. 5 -->
            <a class="tp-caption skin-flat-button tp-resizeme" href="#politique" target="_self" id="slide-1-layer-5" data-x="['left','left','center','center']" data-hoffset="['50','50','0','0']" data-y="['top','top','middle','middle']"
              data-voffset="['452','452','39','31']" data-fontsize="['13','13','12','11']" data-lineheight="['13','13','12','11']" data-fontweight="['700','700','700','700']" data-width="none" data-height="none" data-whitespace="nowrap"
              data-type="text" data-actions='' data-responsive_offset="on"
              data-frames='[{"delay":910,"speed":500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power0.easeIn"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
              data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[16,16,14,12]" data-paddingright="[35,35,30,25]" data-paddingbottom="[16,16,14,12]" data-paddingleft="[35,35,30,25]">Nos informations</a>
          </li>
          <!-- SLIDE  -->
          <li data-index="rs-12" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="300" data-thumb="images/slides/slider-mainbg-002.jpg"
            data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
            <!-- MAIN IMAGE -->
            <img src="images/slides/slider-mainbg-002.jpg" alt="" title="Home 1" data-bgposition="center center" data-bgfit="cover" data-bgrepeat="no-repeat" class="rev-slidebg" data-no-retina>
            <!-- LAYERS -->

            <!-- LAYER NR. 7 -->
            <div class="tp-caption tp-resizeme ttm-textcolor-skincolor" id="slide-2-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','-628','-684']" data-y="['middle','middle','middle','middle']"
              data-voffset="['-149','-149','-116','46']" data-fontsize="['14','14','12','11']" data-lineheight="['14','14','14','14']" data-fontweight="['600','600','700','700']" data-width="none" data-height="none" data-whitespace="nowrap"
              data-visibility="['on','on','off','off']" data-type="text" data-responsive_offset="on"
              data-frames='[{"delay":140,"speed":500,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power0.easeIn"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
              data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"></div>

            <!-- LAYER NR. 8 -->
            <div class="tp-caption tp-resizeme" id="slide-2-layer-2" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['top','top','middle','middle']" data-voffset="['233','233','-77','-60']"
              data-fontsize="['60','60','50','40']" data-lineheight="['75','75','75','60']" data-fontweight="['700','700','700','700']" data-color="['rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)']" data-width="none"
              data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
              data-frames='[{"delay":370,"speed":800,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power0.easeIn"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
              data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]">Une monnaie stable <br>stimule développement<br> économique </div>

            <!-- LAYER NR. 9 -->
            <div class="tp-caption tp-resizeme" id="slide-2-layer-3" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['top','top','middle','middle']" data-voffset="['307','307','-16','-11']"
              data-fontsize="['60','60','50','40']" data-lineheight="['75','75','75','60']" data-fontweight="['700','700','700','700']" data-color="['rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)','rgb(255,255,255)']" data-width="none"
              data-height="none" data-whitespace="nowrap" data-type="text" data-responsive_offset="on"
              data-frames='[{"delay":640,"speed":800,"frame":"0","from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;","to":"o:1;","ease":"Power0.easeIn"},{"delay":"wait","speed":300,"frame":"999","to":"opacity:0;","ease":"Power3.easeInOut"}]'
              data-textAlign="['inherit','inherit','inherit','inherit']" data-paddingtop="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]"></div>
          </li>
          <!-- SLIDE -->          
        </ul>
      </div>
    </div>
    <!-- END REVOLUTION SLIDER -->
    <div class="container">
    <div class="row" style="margin-top: -75px !important;">
    <?php 
    include_once('ajax/indexPolitiqueShow.php');
    ?>
    </div>
     </div>
    <br>
    <br>
    <?php 
    include_once('ajax/indexMediaShow.php');
    ?>
    <!-- Display Media from Index page -->
      
    <!-- Active link per page -->
    <script>
      element = document.getElementById('home');
      element.classList.add("active");
    </script>
    <!-- End of active link -->

    <!-- Footer -->
    <?php 
    include_once('footer.php');
    ?>
