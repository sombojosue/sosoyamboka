<body>

  <!--page start-->
  <div class="page">

    <!-- preloader start -->
    <!--
    <div id="preloader">
      <div id="status">&nbsp;</div>
    </div>
    -->

    <!-- preloader end -->

    <!--header start-->
    <header id="masthead" class="header ttm-header-style-classic">
      <!-- ttm-topbar-wrapper -->
      <div class="ttm-topbar-wrapper ttm-bgcolor-darkgrey ttm-textcolor-white clearfix">
        <div class="container">
          <div class="ttm-topbar-content">
            <ul class="top-contact ttm-highlight-left text-left">
              <li><i class="fa fa-clock-o"></i><strong>Heure d'ouverture:</strong> Lun - Sam 8.00 - 16.00</li>
            </ul>
            <div class="topbar-right text-right">
              <ul class="top-contact">
                <li><i class="fa fa-envelope-o"></i><a href="mailto:sosoyamboka20@yahoo.com">sosoyamboka20@yahoo.com</a></li>
                <li><i class="fa fa-phone"></i>+243 814 006 151</li>
              </ul>
              <div class="ttm-social-links-wrapper list-inline">
                <ul class="social-icons">
                  <li><a href="https://m.facebook.com/sosoya.mboka.9?ref=bookmarks"><i class="fa fa-facebook"></i></a>
                  </li>
                  <li><a href="https://twitter.com/sosoyamboka?s=08"><i class="fa fa-twitter"></i></a>
                  </li>
                  <li><a href="login.php"><i class="fa fa-user"></i></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div><!-- ttm-topbar-wrapper end -->
      <!-- ttm-header-wrap -->
      <div class="ttm-header-wrap">
        <!-- ttm-stickable-header-w -->
        <div id="ttm-stickable-header-w" class="ttm-stickable-header-w clearfix">
          <div id="site-header-menu" class="site-header-menu">
            <div class="site-header-menu-inner ttm-stickable-header">
              <div class="container">
                <!-- site-branding -->
                <div class="site-branding">
                  <a class="home-link" href="index.php" title="Fondex" rel="home">
                    <img id="logo-img" class="img-center" src="images/logo.png" alt="logo-img">
                  </a>
                </div><!-- site-branding end -->
                <!--site-navigation -->
                <div id="site-navigation" class="site-navigation">
                  <div class="ttm-rt-contact">
                    <!-- header-icons -->
                    <div class="ttm-header-icons">
                       <div class="ttm-header-icon ttm-header-search-link">
                        <a href="#"><i class="ti ti-search"></i></a>
                        <div class="ttm-search-overlay">
                <form method="get" class="ttm-site-searchform" action="search.php">
                <div class="w-search-form-h">
                <div class="w-search-form-row">
                <div class="w-search-input" id="bloodhound">
                <input type="search" class="typeahead field searchform-s" name="s" placeholder="Ecrit un mot d'article ici ...">
                <button type="submit"><i class="ti ti-search"></i>
                </button>
                </div>
                </div>
                </div>
                          </form>
                        </div>
                      </div>
                    </div><!-- header-icons end -->
                  </div>
                  <div class="ttm-menu-toggle">
                    <input type="checkbox" id="menu-toggle-form" />
                    <label for="menu-toggle-form" class="ttm-menu-toggle-block">
                      <span class="toggle-block toggle-blocks-1"></span>
                      <span class="toggle-block toggle-blocks-2"></span>
                      <span class="toggle-block toggle-blocks-3"></span>
                    </label>
                  </div>
                  <nav id="menu" class="menu">
                    <ul class="dropdown">
                      <li id="home"><a href="index.php">Accueil</a></li>
                      <li id="news"><a href="#">Actualites</a>
                        <ul>
                          <li><a href="politique.php">Politique</a></li>
                          <li><a href="economie.php">Economie</a></li>
                          <li><a href="societe.php">Societe</a></li>
                          <li><a href="sante.php">Sante</a></li>
                          <li><a href="culture.php">Culture</a></li>
                          <li><a href="education.php">Education</a></li>                
                          <li><a href="sport.php">Sport</a></li>
                          </ul>
                      </li>
                      <li id="about"><a href="about.php">A propos</a></li>
                      <li id="contact"><a href="contact.php">Contact</a></li>
                      <li id="pub"><a href="publicite.php">Publicite</a></li>
                    </ul>
                  </nav>
                </div><!-- site-navigation end-->
              </div>
            </div>
          </div>
        </div><!-- ttm-stickable-header-w end-->
      </div>
      <!--ttm-header-wrap end -->
    </header>
    <!--header end-->
