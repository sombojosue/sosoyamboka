<!--footer start-->
    <footer class="footer widget-footer clearfix">
      <div class="first-footer">
        <div class="container">
          <div class="row">
            <div class="col-lg-12 text-center">
              <div class="first-footer-inner">
                <div class="footer-logo">
                  <img id="footer-logo-img" class="img-center" src="images/footer-logo.png" alt="footer" width="700" height="450">
                </div>
                <div class="row no-gutters footer-box">
                  <div class="col-md-4 widget-area">
                    <div class="featured-box text-center">
                      <div class="featured-content">
                        <div class="featured-title">
                          <h5>Notre adresse</h5>
                        </div>
                        <div class="featured-desc">
                          <p>C/Linguala Q/ Zigida Av/ Lutumba Simaro</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 widget-area">
                    <div class="featured-box text-center">
                      <div class="featured-content">
                        <div class="featured-title">
                          <h5>Contactez-nous</h5>
                        </div>
                        <div class="featured-desc">
                          <p>+243 814 006 151 </p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-4 widget-area">
                    <div class="featured-box text-center">
                      <div class="featured-content">
                        <div class="featured-title">
                          <h5>Mail</h5>
                        </div>
                        <div class="featured-desc">
                          <p>sosoyamboka@yahoo.com</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row no-gutters">
                  <div class="col-md-3 col-sm-2"></div>
                  <div class="col-md-6 col-sm-8">
                    <div class="">
                      <form id="subscribe-form" class="newsletter-form" method="post">
                        <div class="mailchimp-inputbox clearfix" id="subscribe-content">
                          <i class="fa fa-envelope-o"></i>
                          <input type="email" id="emailSend" placeholder="Entre votre email ici ..." required="" >
                          <input type="submit" value="Abonnez-vous   " style="width: 28%;" onclick="return SendMessage()">
                        </div>
                        <div id="msgGet"></div>
                      </form>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-2"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="second-footer ttm-textcolor-white">
        <div class="container">
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 widget-area">
              <div class="widget widget_text  clearfix">
                <h3 class="widget-title">A propos SOSO YA BOKA</h3>
                <div class="textwidget widget-text text-justify">
                  Sosoyamboka.infos est le Premier média de proximité en ligne. Suivez l’actualité dans tous les volets, politique, social, économique… de la République démocratique du Congo comme d’ailleurs.
                  <br><br>
                  <div class="social-icons circle social-hover">
                    <ul class="list-inline">
                      <li><a  href="https://m.facebook.com/sosoya.mboka.9?ref=bookmarks" ><i class="fa fa-facebook"></i></a>
                      <li><a href="https://twitter.com/sosoyamboka?s=08" ><i class="fa fa-twitter"></i></a>
                  </li>
                  <li><a href="login.php"><i class="fa fa-user"></i></a>
                  </li>
                    </ul>
                  </div>
                  <br>
                  <div class="mb-20">
                    <a class="ttm-btn ttm-btn-size-xs ttm-btn-shape-square ttm-btn-style-fill ttm-btn-bgcolor-skincolor ttm-btn-color-white" href="about.php">Lire la suite</a>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 widget-area">
              <div class="widget widget_nav_menu clearfix">
                <h3 class="widget-title">Lien rapide </h3>
                <ul id="menu-footer-services">
                  <li><a href="politique.php">Politique</a></li>
                  <li><a href="economie.php">Economie</a></li>
                  <li><a href="culture.php">Culture</a></li>
                  <li><a href="sante.php">Santé</a></li>
                  <li><a href="education.php">Education</a></li>
                  <li><a href="societe.php">Societé</a></li>
                  <li><a href="sport.php">Sport</a></li>
                </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 widget-area">
              <div class="widget widget_text clearfix">
                <h3 class="widget-title">Dernières actualités</h3>
              <ul class="widget-post ttm-recent-post-list">
        <?php
        require('includes/db_config.php');
        //Function to return only 100 charactere
        function charlimite($string, $limit) {
        return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
        }

        $sql_pol = "SELECT title,image,infodate,displayid FROM tbl_news  ORDER BY infodate DESC LIMIT 3 ";
        

  $res_pol = mysqli_query($con, $sql_pol);
  if (mysqli_num_rows($res_pol)) {
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>
                  <li>
                    <a href="article.php?info=<?php echo $row_pol['displayid'];?>"><img src="<?php echo $row_pol['image'];?>" alt="post-img" style="width: 70px;height: 70px;"></a>
                    <span class="post-date"><?php echo $row_pol['infodate'];?></span>
                    <a href="article.php?info=<?php echo $row_pol['displayid'];?>"><?php echo charlimite($row_pol['title'], 40);?></a>
                  </li>
  <?php }}?>
            </ul>
              </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-3 widget-area">
              <div class="widget flicker_widget clearfix">
                <h3 class="widget-title">Notre localisation</h3>
                <div class="textwidget widget-text">
                  <img src="images/map-footer.png" class="img-fluid" alt="map-footer">
                  <br>
                  <br>
                  <ul class="ttm-our-location-list">
                    <li><i class="fa fa-map-marker"></i>RDC : +243 814 006 151</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bottom-footer-text ttm-textcolor-white">
        <div class="container">
          <div class="row copyright">
            <div class="col-md-12">
              <div class="">
                <span>Copyright © 2020&nbsp;<a href="index.html">SOSOYAMBOKA</a>. All rights reserved.</span>
              </div>
            </div>
            <div class="col-md-12">
              <ul id="menu-footer-menu" class="footer-nav-menu">
            <li><a href="about.php">A propos</a></li>
            <li><a href="contact.php">Contact</a></li>
           <li><a>Design by Josue lotshango</a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </footer>
    <!--footer end-->

    <!--back-to-top start-->
    <a id="totop" href="#top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!--back-to-top end-->

  </div><!-- page end -->

  <script>
    //remove default form behaviour
      document.getElementById('subscribe-form').addEventListener("submit",function(event){
        event.preventDefault()
      });

      function SendMessage() {
      
      var xhttp = new XMLHttpRequest();
      var msgGet = document.getElementById('msgGet');
      
      //getting input from the user
    var email = document.getElementById('emailSend').value;
    xhttp.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
      msgGet.style.display = 'inline';
      msgGet.innerHTML = this.responseText;
      document.getElementById("subscribe-form").reset();
      }
   };
  xhttp.open("POST", "ajax/subscribeSend.php", true);
  xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
  xhttp.send("email="+email);
}
  </script>
  <!-- Javascript -->

  <script src="js/jquery.min.js"></script>
  <script src="js/tether.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.js"></script>
  <script src="js/jquery-waypoints.js"></script>
  <script src="js/jquery-validate.js"></script>
  <script src="js/owl.carousel.js"></script>
  <script src="js/jquery.prettyPhoto.js"></script>
  <script src="js/numinate.min.js?ver=4.9.3"></script>
  <script src="js/main.js"></script>
  <script src="js/chart.js"></script>

  <!-- Revolution Slider -->
  <script src="js/jquery.themepunch.tools.min.js"></script>
  <script src="js/jquery.themepunch.revolution.min.js"></script>
  <script src="js/slider.js"></script>


  <!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->

  <script src="js/revolution.extension.actions.min.js"></script>
  <script src="js/revolution.extension.carousel.min.js"></script>
  <script src="js/revolution.extension.kenburn.min.js"></script>
  <script src="js/revolution.extension.layeranimation.min.js"></script>
  <script src="js/revolution.extension.migration.min.js"></script>
  <script src="js/revolution.extension.navigation.min.js"></script>
  <script src="js/revolution.extension.parallax.min.js"></script>
  <script src="js/revolution.extension.slideanims.min.js"></script>
  <!-- <script src="js/typeahead.bundle.js"></script>-->
  <!-- Javascript end-->
      <script>
    var states = <?php echo '["' . implode('", "', $codesearch) . '"]' ?>;
  // constructs the suggestion engine
var states = new Bloodhound({
  datumTokenizer: Bloodhound.tokenizers.whitespace,
  queryTokenizer: Bloodhound.tokenizers.whitespace,
  // `states` is an array of state names defined in "The Basics"
  local: states
});

$('#bloodhound .typeahead').typeahead({
  hint: true,
  highlight: true,
  minLength: 1
},
{
  name: 'states',
  source: states
});

    </script>

</body>

</html>
