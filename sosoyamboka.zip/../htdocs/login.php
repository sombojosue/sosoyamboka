<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="keywords" content="soso ya mboka, rdc info, congo news, congo actualites, congo information" />
  <meta name="description" content="soso ya mboka donne les information real et correct sur la rdc" />
  <meta name="author" content="SOSO YA MBOKA" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
  <title>SOSO YA MBOKA  </title>
  <!-- favicon icon -->
  <link rel="shortcut icon" href="images/fav-logo.png" />
  <!-- favicon icon -->
  <link rel="shortcut icon" href="images/fav-log.png" />


  <!-- bootstrap -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
  <style>
    .display-none{
      display: none;
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-sm navbar-dark p-0" style="background-color: rgb(11,12,38);">
    <div class="container">
      <a href="index.php" class="navbar-brand"><i class="fa fa-home mr-2"></i>SOSO YA MBOKA</a>
    </div>
  </nav>

  <!-- HEADER -->
  <header  class="py-2 text-white" style="background:#f71735 !important;">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h4>Bienvenu Admin</h4>
        </div>
      </div>
    </div>
  </header>

  <!-- Error handling when user click submit button -->
     <div class="display-none">
     <div class="alert alert-danger alert-dismissible fade show" role="alert" style="width: 30%;">
       <strong class="msg">Utilisateur et mot de pass sont incorrect</strong>
       <button type="button" class="close" data-dismiss="alert" aria-label="Close">
      <span aria-hidden="true">&times;</span>
      </button>
   </div>
</div>
<!-- End of error handling -->
  <!-- ACTIONS -->
  <section id="actions" class="py-4 mb-4">
    <div class="container">
      <div class="row">

      </div>
    </div>
  </section>

  <!-- LOGIN -->
  <section id="login">
    <div class="container">
      <div class="row">
        <div class="col-md-5 mx-auto">
          <div class="card">
            <div class="card-header">
              <h4>Connexion au compte</h4>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" name="user" autocomplete="off">
                </div>
                <div class="form-group">
                  <label for="password">Mot de pass</label>
                  <input type="password" class="form-control" name="password" autocomplete="off">
                </div>
                <input type="submit" value="Login" class="btn  btn-block text-white" name="login" style="background:#f71735;">
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="main-footer" class="text-white mt-5 p-3" style="position: absolute;bottom:0;width: 100%;background-color: rgb(11,12,38);">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">
            Copyright &copy;
            <span id="year"></span>
            SOSOYAMBOKA
          </p>
        </div>
      </div>
    </div>
  </footer>

  <!-- Checking user credential -->
<?php
if (isset($_POST['login'])) {
  require_once('includes/db_config.php');
  $user = mysqli_escape_string($con, $_POST['user']);
  $pass = mysqli_escape_string($con, $_POST['password']);
  //get hash pass
  $hashpass = md5($pass);
  //checking user detail inside the database
  $sql = "select * from tbl_user where email = '$user' and psswd = '$hashpass'";
  $query = mysqli_query($con, $sql);

  //Checking user for empty login account
  if (empty($user)) {
    echo "
  <script>
      var showError = document.querySelector('.display-none');
      var showMsg = document.querySelector('.msg');
      showError.style.display = 'block';
      showMsg.innerHTML = 'Pardon entre l\'utilisateur'
    </script>      
  ";  
  return false;
  }
  if (empty($pass)) {
    echo "
  <script>
      var showError = document.querySelector('.display-none');
      var showMsg = document.querySelector('.msg');
      showError.style.display = 'block';
      showMsg.innerHTML = 'Pardon entre le mot de pass'
    </script>      
  ";  
  return false;
  }
  if (mysqli_num_rows($query) > 0) {
   while ($row = mysqli_fetch_assoc($query)) {
    //get user information inside the database
    $user = $row['email'];

    
      session_start();
        $_SESSION['user'] = $user;
        header("location: admin/index.php");
   }
  }else{
    echo "
  <script>
      var showError = document.querySelector('.display-none');
      showError.style.display = 'block';
    </script>      
  ";
  }

}
?>

  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>


  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());
  </script>
</body>

</html>