<?php
   require('../../includes/db_config.php');

   $sql = "SELECT count(id) as val FROM subscribe";
   $result = mysqli_query($con,$sql);
   if(mysqli_num_rows($result) > 0){
   while($row = mysqli_fetch_assoc($result)){
     $data[] = $row['val'];
   }
   
   echo json_encode($data);
}
?>