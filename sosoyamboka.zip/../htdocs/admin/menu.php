<?php 

require('../includes/db_config.php');

if (isset($user)) {
  
  $sql_pol = "SELECT * FROM tbl_user  where email='$user'";
  $res_pol = mysqli_query($con, $sql_pol);
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {
  $name = $row_pol['name'];
  $email = $row_pol['email'];
  $avatar = $row_pol['avatar'];
  $password = $row_pol['psswd'];
}
}

//get number of post and others informations
$sql_poli = "SELECT id FROM tbl_news  where type_of_info='politique'";
$res_poli = mysqli_query($con, $sql_poli);
$numPoli = mysqli_num_rows($res_poli);

$sql_eco = "SELECT id FROM tbl_news  where type_of_info='economie'";
$res_eco = mysqli_query($con, $sql_eco);
$numEcon = mysqli_num_rows($res_eco);

$sql_cult = "SELECT id FROM tbl_news  where type_of_info='culture'";
$res_cult = mysqli_query($con, $sql_cult);
$numCult = mysqli_num_rows($res_cult);

$sql_sant = "SELECT id FROM tbl_news  where type_of_info='sante'";
$res_sant = mysqli_query($con, $sql_sant);
$numSant = mysqli_num_rows($res_sant);

$sql_edu = "SELECT id FROM tbl_news  where type_of_info='education'";
$res_edu = mysqli_query($con, $sql_edu);
$numEdu = mysqli_num_rows($res_edu);

$sql_soci = "SELECT id FROM tbl_news  where type_of_info='societe'";
$res_soci = mysqli_query($con, $sql_soci);
$numSoci = mysqli_num_rows($res_soci);

$sql_spor = "SELECT id FROM tbl_news  where type_of_info='sport'";
$res_spor = mysqli_query($con, $sql_spor);
$numSpor = mysqli_num_rows($res_spor);

$sql_med = "SELECT id FROM tbl_newsmedia ";
$res_med = mysqli_query($con, $sql_med);
$numMedia = mysqli_num_rows($res_med);

?>
<body>

  
  <nav class="navbar navbar-expand-sm navbar-dark bg-dark p-0">
    <div class="container">
      <a href="index.php" class="navbar-brand text-light">SOSOYAMBOKA</a>
      <button class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarCollapse">
        <ul class="navbar-nav">
          <li class="nav-item px-2" id="home">
            <a href="index.php" class="nav-link">Accueil</a>
          </li>
          <li class="nav-item px-2" id="post-link">
            <a href="posts.php" class="nav-link">Publication</a>
          </li>
          <li class="nav-item px-2" id="contact-link">
            <a href="contact.php" class="nav-link">Contact</a>
          </li>
          <li class="nav-item px-2" id="user">
            <a href="users.php" class="nav-link">Utilisateurs</a>
          </li>
          <li class="nav-item px-2" id="pub">
            <a href="pub.php" class="nav-link">Publicité</a>
          </li>
        </ul>

        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown mr-3">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
              <img src="<?php echo '../'.$avatar;?>" width='37' height='37' style="border-radius: 50%;"> Bienvenue <?php echo $name;?>
            </a>
            <div class="dropdown-menu">
              <a href="profile.php" class="dropdown-item">
                <i class="fas fa-user-circle"></i> Profil
              </a>
              <a href="logout.php" class="dropdown-item">
                <i class="fas fa-sign-out-alt"></i> Se déconnecter
              </a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>
