<?php
include_once('header.php');
include_once('menu.php');
?>
  <!-- HEADER -->
  <header id="main-header" class="py-2 bg-success text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h4>
            <i class="fas fa-address-book"></i> Contact</h4>
        </div>
      </div>
    </div>
  </header>

  <!-- SEARCH -->
  <section id="search" class="py-4 mb-4 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-6 ml-auto">
          
        </div>
      </div>
    </div>
  </section>

  <!-- CATEGORIES -->
  <section id="categories">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4>Dernières contact</h4>
            </div>
            <table class="table table-striped">
              <thead class="thead-dark">
                <tr>
                  <th>#</th>
                  <th>Nom</th>
                  <th>Email</th>
                  <th>Subject</th>
                  <th>Message</th>
                  <th></th>
                </tr>
              </thead>
<tbody>
                <?php 

              require('../includes/db_config.php');
             $number_per_page = 25;
       //find out the number of result stored in databases
        $sql = "select * from contact";
       $res = mysqli_query($con, $sql);
       $number_of_results = mysqli_num_rows($res);

       // determine number of total result
       $number_of_pages = ceil($number_of_results/$number_per_page);
       //determine which page number the visitor is currently on
       if (!isset($_GET['page'])) {
          $page = 1;
        } else{
          $page = $_GET['page'];
        }
        $current = $page;
        $previous = $page - 1;
        $next = $page + 1;
        //determine the sql  LIMIT number
        $this_page_first_result = ($page - 1) * $number_per_page; 
        //retrive data from mysql database
        
        $sql_pol = "SELECT * FROM contact ORDER BY contactdate DESC LIMIT " . $this_page_first_result .",".$number_per_page;
       
        
       $id = 1;
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol)) {
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>

                <tr>
                  <td><?php echo $id++;?></td>
                  <td><h6><?php echo $row_pol['name'];?></h6></td>
                  <td><?php echo $row_pol['email'];?></td>
                  <td><?php echo $row_pol['subject'];?></td>
                  <td><?php echo $row_pol['message'];?></td>
        
                  <td>
                    <img src="../images/watch.png" width="20"><?php echo $row_pol['contactdate'];?>
                    </a>
                  </td>
                </tr>
              <?php }}?>
               </tbody>
            </table>

          </div>
        </div>

        <!-- PAGINATION -->
            <?php
  // display the links to page
      echo "
      <nav aria-label='Page navigation example mt-2' id='center'>
      <ul class='pagination'>";
      if ($previous != 0) {
      echo '<li class="page-item"><a class="page-link" href="contact.php?page='.$previous.'">'."<i class='fas fa-backward'></i>".'</a></li>';
       }
      for ($page=1; $page<=$number_of_pages ; $page++) { 
        if ($current != $page) {
         echo '<li class="page-item "><a class="page-link" href="contact.php?page='.$page.'">'.$page.'</a></li>'; 
        }else{
        echo '<li class="page-item bg-primary"><a class="page-link bg-primary text-white"  href="contact.php?page='.$page.'">'.$page.'</a></li>';
        }
      }
        echo '<li class="page-item "><a class="page-link" href="contact.php?page='.$next.'">'."<i class='fas fa-forward text-dark'></i>".'</a></li>';
      echo "
      </ul>
      </nav>";
  ?>        
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="main-footer" class="text-white mt-5 p-3" style="background-color: rgb(11,12,38);position: absolute;bottom: 0;width: 100%;">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">
            Copyright &copy;
            <span id="year"></span>
            SOSOYAMBOKA
          </p>
        </div>
      </div>
    </div>
  </footer>

<!-- Active link per page -->
    <script>
      element = document.getElementById('contact-link');
      element.classList.add("active")
    </script>
    <!-- End of active link -->

  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>


  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());
  </script>
</body>

</html>