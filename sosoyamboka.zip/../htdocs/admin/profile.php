<?php
include_once('header.php');
include_once('menu.php');
?>
<?php 

require('../includes/db_config.php');
if (isset($user)) {
  
  $sql_pol = "SELECT * FROM tbl_user  where email='$user'";
  $res_pol = mysqli_query($con, $sql_pol);
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {
  $name = $row_pol['name'];
  $email = $row_pol['email'];
  $avatar = $row_pol['avatar'];
  $password = $row_pol['psswd'];
}
}
?>
  <!-- HEADER -->
  <header id="main-header" class="py-2 bg-primary text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h4>
            <i class="fas fa-user"></i> Modifie Profil</h4>
        </div>
      </div>
    </div>
  </header>

  <!-- ACTIONS -->
  <section id="actions" class="py-4 mb-4 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <a href="index.php" class="btn btn-light btn-block">
            <i class="fas fa-arrow-left"></i> Retour au tableau de bord
          </a>
        </div>
        <div class="col-md-3">
          <a  class="btn btn-danger btn-block text-white" title="Pardon contact system admin">
            <i class="fas fa-trash"></i> Supprimer le compte
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- PROFILE -->
  <section id="profile">
    <div class="container">
      <div class="row">
        <div class="col-md-9">
          <div class="card">
            <div class="card-header">
              <h4>Modifie Profil</h4>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <label for="name">Nom</label>
                  <input type="text" class="form-control" value="<?php echo $name;?>" name='name'>
                </div>
                <div class="form-group">
                  <label for="email">Email</label>
                  <input type="email" class="form-control" value="<?php echo $email;?>">
                </div>
                <div class="form-group">
                  <label for="pass">Password</label>
                  <input type="password" name="password" id="pass" class="form-control" value="<?php echo $password;?>">
                </div>
                <div class="form-group">
                  <button type="submit" name="update" class="btn btn-primary"><i class="fas fa-check"></i> Sauvegarde</button>
                </div>
              </form>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <h3>Votre Avatar</h3>
          <img src="<?php echo "../$avatar";?>" alt="sorry" class="d-block img-fluid mb-3" width='300' height='290' style='border-radius: 50%;'>
          <button class="btn btn-primary btn-block" data-toggle="modal" data-target="#avatar">Modifie votre photo</button>
        </div>
      </div>
    </div>
  </section>

 <!-- FOOTER -->
  <footer id="main-footer" class="text-white mt-5 p-3" style="background-color: rgb(11,12,38);">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">
            Copyright &copy;
            <span id="year"></span>
            SOSOYAMBOKA
          </p>
        </div>
      </div>
    </div>
  </footer>


  <!-- MODALS -->

  
  <!-- Modal Logout -->
<div class="modal fade" id="avatar" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body text-center">
        <form class="form-group" method="post" enctype="multipart/form-data">
          <label for="image"></label>
          <input type="hidden" name="MAX_FILE_SIZE" value="30000000">
          <input type="file" name="file" id="image">
          
          <button type="submit" class="btn btn-primary" name="uploadimg">Upload</button>
        </form>
      </div>

    </div>
  </div>
</div>
<!-- End of logout -->

  
  <?php 
 if (isset($_POST['update'])) {
   $name = $_POST['name'];
   $password_edit = $_POST['password'];
   $pass = md5($password_edit);
   
   $query = "update tbl_user set name='$name',psswd='$pass' where email='$email'";
   $res = mysqli_query($con, $query);
   if ($res) {
     echo "<script> 
     alert('Les information ont ete modifie avec success')
     window.location = 'logout.php';
     </script>";
   }
 }
?>

<!-- Finish upload image with php -->
<?php 
 if (isset($_POST['uploadimg'])) {
   $file_name = $_FILES['file']['name'];
   $file_type = $_FILES['file']['type'];
   $file_error = $_FILES['file']['error'];
   $file_size = $_FILES['file']['size'];
   $file_tmp = $_FILES['file']['tmp_name'];
   $path = '../images/avatar';
   $pathup = $path.$file_name;
   $pathdb = 'images/avatar/'.$file_name;
   $appudate = md5($name);
   

   //checking file extension
      if ($file_error === 0){
      switch ($file_type) {
      case 'image/png':
      $filename = $appudate.'.png';
      $pathname = $path.'/'.$filename;
      $sqldb = 'images/avatar'.'/'.$filename;
      $sql = "update tbl_user set avatar ='$sqldb' where email ='$email'";
      $res = mysqli_query($con, $sql);
      if ($res) {
      if(move_uploaded_file($file_tmp, $pathname)){
       echo "
           <script>
           alert('image a ete modifier')
          </script>
       "; 
      }
      }
      break;
      case 'image/jpeg':
      $filename = $appudate.'.png';
      $pathname = $path.'/'.$filename;
      $sqldb = 'images/avatar'.'/'.$filename;
      $sql = "update tbl_user set avatar ='$sqldb' where email ='$email'";
      $res = mysqli_query($con, $sql);
      if ($res) {
      if(move_uploaded_file($file_tmp, $pathname)){
       echo "
           <script>
           alert('image a ete modifier')
          </script>
       "; }
      }
      break;
      case 'image/gif':
      $filename = $appudate.'.png';
      $pathname = $path.'/'.$filename;
      $sqldb = 'images/avatar'.'/'.$filename;
      $sql = "update tbl_user set avatar ='$sqldb' where email ='$email'";
      $res = mysqli_query($con, $sql);
      if ($res) {
      if(move_uploaded_file($file_tmp, $pathname)){
       echo "
           <script>
           alert('image a ete modifier')
          </script>
       "; 
      }
      }
      break;
      case 'image/jpg':
      $filename = $appudate.'.png';
      $pathname = $path.'/'.$filename;
      $sqldb = 'images/avatar'.'/'.$filename;
      $sql = "update tbl_user set avatar ='$sqldb' where email ='$email'";
      $res = mysqli_query($con, $sql);
      if ($res) {
      if(move_uploaded_file($file_tmp, $pathname)){
       echo "
           <script>
           alert('image a ete modifier')
          </script>
       "; 
      }
      }
      break;
      default:
      echo "Please choose image file  ";
    }
  }
 }
?>
<!-- End of finish upload image -->



  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>

  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());

    CKEDITOR.replace('editor1');

    var loadFile = function(event){
        var image = document.querySelector('#imageloader');
        image.src = URL.createObjectURL(event.target.files[0]);
      };
       function showimage(){
     var img = document.querySelector('#imageloader');
     img.style.display = 'inline-block'; 
    }
  </script>
</body>

</html>