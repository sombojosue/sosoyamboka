
<?php
session_start();

if (!isset($_SESSION['user'])) {
  header("location: ../login.php");
}
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="keywords" content="soso ya mboka, rdc info, congo news, congo actualites, congo information" />
  <meta name="description" content="soso ya mboka donne les information real et correct sur la rdc" />
  <meta name="author" content="SOSO YA MBOKA" />
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp"
    crossorigin="anonymous">
  <title>SOSO YA MBOKA  </title>
  <!-- favicon icon -->
  <link rel="shortcut icon" href="img/img-fav.png" />

  <!-- bootstrap -->
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" />
  <!-- Customer style -->
  <link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
