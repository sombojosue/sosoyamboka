<?php
include_once('header.php');
include_once('menu.php');
?>

<!-- Checking if which page has got clicked -->
<?php 
$post = '';
$contact = '';

require('../includes/db_config.php');
if (isset($_GET['post'])) {
  
  $post = $_GET['post'];
  $sql_pol = "SELECT * FROM tbl_news  where displayid='$post'";
  $res_pol = mysqli_query($con, $sql_pol);
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {
  $title = $row_pol['title'];
  $mesg = $row_pol['message'];
  $image = $row_pol['image'];
  $categorie = $row_pol['type_of_info'];
}
}
//Publicite show detail
if (isset($_GET['pub'])) {
  
  $post = $_GET['pub'];
  $sql_pol = "SELECT * FROM tbl_pub  where displayid='$post'";
  $res_pol = mysqli_query($con, $sql_pol);
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {
  $title = $row_pol['title'];
  $mesg = $row_pol['message'];
  $image = $row_pol['image'];
  $categorie = 'Publicite';
}
}

if (isset($_GET['contact'])) {
  
  $contact = $_GET['contact'];
  $sql_pol = "SELECT * FROM contact  where email='$contact'";
  $res_pol = mysqli_query($con, $sql_pol);
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {
  $name = $row_pol['name'];
  $email= $row_pol['email'];
  $subject = $row_pol['subject'];
  $message = $row_pol['message'];
}
}

?>
  <!-- HEADER -->
  <header id="main-header" class="py-2 bg-primary text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h1>
            detail trouve</h1>
        </div>
      </div>
    </div>
  </header>

  <!-- ACTIONS -->
  <section id="actions" class="py-4 mb-4 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <a href="index.php" class="btn btn-light btn-block">
            <i class="fas fa-arrow-left"></i> Rentre au Tableau de bord
          </a>
        </div>
       
        <?php 
        if (isset($_GET['contact'])) {?>
        <div class="col-md-3">
          <a href="details.php?deletecon=<?php echo $contact;?>" class="btn btn-danger btn-block">
            <i class="fas fa-trash"></i> Suprime
          </a>
        </div>
      <?php }?>
      <?php 
        if (isset($_GET['post'])) {?>
        <div class="col-md-3">
          <a href="details.php?deletepost=<?php echo $post;?>" class="btn btn-danger btn-block">
            <i class="fas fa-trash"></i> Suprime
          </a>
        </div>
      <?php }?>

      </div>
    </div>
  </section>

  <!-- Contact detail -->

  <?php 
   if ($contact !== '') {?>
   <section id="details">
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="card-header">
              <h4>Contact detail</h4>
            </div>
            <div class="card-body">
              <form>
                <div class="form-group">
                  <label for="title">Nom</label>
                  <input type="text" class="form-control" value="<?php echo $name;?>" name='title'>
                </div>
                <div class="form-group">
                  <label for="category">Email</label>
                  <input type="text" name="categorie" class="form-control" value="<?php echo $email;?>">
                </div>
                <div class="form-group">
                  <label for="category">Subject</label>
                  <input type="text" name="categorie" class="form-control" value="<?php echo $subject;?>">
                </div>
                <div class="form-group">
                  <label for="body">Message</label>
                  <textarea name="editor1" class="form-control"><?php echo $message;?></textarea>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>



  <?php }?>

  <!-- DETAILS  FOR POST-->
  <?php 
  if ($post !== '') {
  ?>
  <section id="details">
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="card-header">
              <h4>Modifie la publication</h4>
            </div>
            <div class="card-body">
              <form method="post">
                <div class="form-group">
                  <label for="title">Titre</label>
                  <input type="text" class="form-control" value="<?php echo $title;?>" name='title'>
                </div>
                <div class="form-group">
                  <label for="category">Category</label>
                  <input type="text" name="categorie" class="form-control" value="<?php echo $categorie;?>">
                </div>
                <div class="form-group">
                  <img src="<?php echo '../'.$image;?>" width='400' height='300'>
                </div>
                <div class="form-group">
                  <label for="body">Information</label>
                  <textarea name="editor1" class="form-control"><?php echo $mesg;?></textarea>
                </div>
                <div class="form-group">
                  <?php if (isset($_GET['post'])) {?>
                  
                  <button type="submit" name="update" class="btn btn-primary"><i class="fas fa-check"></i> Sauvegarde</button>
                  <?php }?>

                  <?php if (isset($_GET['pub'])) {?>
                  
                  <button type="submit" name="updatepub" class="btn btn-primary"><i class="fas fa-check"></i> Sauvegarde</button>
                  <?php }?>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
 <?php }elseif (!isset($_GET['contact'])) {?>
  <!-- POSTS -->
  <section id="posts">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4>Dernières publications</h4>
            </div>
            <table class="table table-striped">
              <thead class="thead-dark">
                <tr>
                  <th>#</th>
                  <th>Titre</th>
                  <th>Information</th>
                  <th>Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php 

              require('../includes/db_config.php');
            //Function to return only 100 charactere
            function charlimit($string, $limit) {
            return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
            } 

        $sql_pol = "SELECT * FROM tbl_news  ORDER BY infodate DESC LIMIT 13 ";
        
       $id = 1;
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol)) {
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>

                <tr>
                  <td><?php echo $id++;?></td>
                  <td><h6><?php echo charlimit($row_pol['title'], 30);?></h6></td>
                  <td><?php echo charlimit($row_pol['message'], 90);?></td>
                  <td><?php echo $row_pol['infodate'];?></td>
                  <td>
                    <a href="details.php?post=<?php echo $row_pol['displayid'];?>" class="btn btn-secondary">
                      <i class="fas fa-angle-double-right"></i> Details
                    </a>
                  </td>
                </tr>
              <?php }}?>
              </tbody>
            </table>
          </div>
        </div>
 <?php }?>
  <!-- FOOTER -->
  <footer id="main-footer" class="text-white mt-5 p-3" style="background-color: rgb(11,12,38);">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">
            Copyright &copy;
            <span id="year"></span>
            SOSOYAMBOKA
          </p>
        </div>
      </div>
    </div>
  </footer>

 <?php 
 if (isset($_POST['update'])) {
   $title = $_POST['title'];
   $categorie = $_POST['categorie'];
   $message = $_POST['editor1'];
   $query = "update tbl_news set title='$title',type_of_info='$categorie',message='$message' where displayid='$post'";
   $res = mysqli_query($con, $query);
   if ($res) {
     echo "<script> 
     alert('Les information ont ete modifie avec success')
     window.location = 'posts.php';
     </script>";
   }
 }
?>
<?php 
 if (isset($_POST['updatepub'])) {
   $title = $_POST['title'];
   $message = $_POST['editor1'];
   $query = "update tbl_pub set title='$title',message='$message' where displayid='$post'";
   $res = mysqli_query($con, $query);
   if ($res) {
     echo "<script> 
     alert('Les information ont ete modifie avec success')
     window.location = 'pub.php';
     </script>";
   }
 }
?>

<?php 
if (isset($_GET['deletepost'])) {
  $del = $_GET['deletepost'];
  $del_query = "delete from tbl_news where displayid='$del'";
  $del_res = mysqli_query($con, $del_query);
  if($del_res){
  echo "<script> 
     alert('Les information ont ete suprime avec success')
     window.location = 'posts.php';
     </script>";
   }
}
?>

<?php 
if (isset($_GET['deletecon'])) {
  echo "<script> 
     alert('Les information ont ete suprime avec success')
     window.location = 'contact.php';
     </script>";
}
?>

  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>

  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());

    CKEDITOR.replace('editor1');
  </script>
</body>

</html>