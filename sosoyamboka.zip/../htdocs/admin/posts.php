<?php
include_once('header.php');
include_once('menu.php');
?>
  <!-- HEADER -->
  <header id="main-header" class="py-2 bg-primary text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-7">
          <h4>
            <i class="fas fa-pencil-alt"></i> Publication</h4>
        </div> 
        <div class="col-md-3">
          <a href="#" class="btn btn-danger btn-block" data-toggle="modal" data-target="#addPostModal">
            <i class="fas fa-plus"></i> Ajouter Publication
          </a>
        </div>
        <div class="col-md-2">
          <a href="#" class="btn btn-danger btn-block" data-toggle="modal" data-target="#addVideoModal">
            <i class="fas fa-video"></i> Ajouter Media
          </a>
        </div>     
      </div>
    </div>
  </header>

  <!-- SEARCH -->
  <section id="search" class="py-4 mb-4 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-6 ml-auto">
          <form method="post" action="research.php">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Chercher Publication..." name="input" autocomplete="off">
            <div class="input-group-append">
              <button class="btn btn-primary" name="search" type="submit"><i class="fas fa-search"></i></button>
            </div>
          </div>
        </form>
        </div>
      </div>
    </div>
  </section>

  <!-- POSTS -->
  <section id="posts">
    <div class="container">
      <div class="row">
      <div class="col-md-2">
          <span class="post-box"><i class="fas fa-pencil-alt text-primary"></i>&nbsp;Politique<br><label class="politique"><?php echo $numPoli;?></label></span>
          <span class="post-box"><i class="fas fa-pencil-alt text-danger"></i>&nbsp;Economie<br><label class="economie"><?php echo $numEcon;?></label></span>
          <span class="post-box"><i class="fas fa-pencil-alt text-success"></i>&nbsp;Culture<br><label class="culture"><?php echo $numCult;?></label></span>
          <span class="post-box"><i class="fas fa-pencil-alt text-secondary"></i>&nbsp;Sante<br><label class="sante"><?php echo $numSant;?></label></span>
          <span class="post-box"><i class="fas fa-pencil-alt text-warning"></i>&nbsp;Education<br><label class="education"><?php echo $numEdu;?></label></span>
          <span class="post-box"><i class="fas fa-pencil-alt text-info"></i>&nbsp;Societe<br><label class="societe"><?php echo $numSoci;?></label></span>
          <span class="post-box"><i class="fas fa-pencil-alt" style="color:green;"></i>&nbsp;Sports<br><label class="sport"><?php echo $numSpor;?></label></span>
          <span class="post-box"><i class="fas fa-video text-danger"></i>&nbsp;Media<br><label class="sport"><?php echo $numMedia;?></label></span>
        </div>
        <div class="col-md-10">
          <div class="card">
            <div class="card-header">
              <h4>Dernières publications</h4>
            </div>
            <table class="table table-striped">
              <thead class="thead-dark">
                <tr>
                  <th>#</th>
                  <th>Titre</th>
                  <th>Information</th>
                  <th>Date</th>
                  <th>Vue</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php 

              require('../includes/db_config.php');
              //define how many result per page 
       $number_per_page = 25;
       //find out the number of result stored in databases
        $sql = "select * from tbl_news";
       $res = mysqli_query($con, $sql);
       $number_of_results = mysqli_num_rows($res);

       // determine number of total result
       $number_of_pages = ceil($number_of_results/$number_per_page);
       //determine which page number the visitor is currently on
       if (!isset($_GET['page'])) {
          $page = 1;
        } else{
          $page = $_GET['page'];
        }
        $current = $page;
        $previous = $page - 1;
        $next = $page + 1;
        //determine the sql  LIMIT number
        $this_page_first_result = ($page - 1) * $number_per_page; 
        //retrive data from mysql database
        
        $sql_pol = "SELECT * FROM tbl_news ORDER BY infodate DESC LIMIT " . $this_page_first_result .",".$number_per_page;
       
            //Function to return only 100 charactere
            function charlimit($string, $limit) {
            return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
            } 
        
       $id = 1;
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol)) {
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>

                <tr>
                  <td><?php echo $id++;?></td>
                  <td><h6><?php echo charlimit($row_pol['title'], 30);?></h6></td>
                  <td><?php echo charlimit($row_pol['message'], 90);?></td>
                  <td><?php echo $row_pol['infodate'];?></td>
                  <!-- Get number of people that watch our news -->
                  <td>
                    <?php
                    $idvue = $row_pol['displayid'];
                    $vueres=mysqli_query($con, "select * from viewpost where displayid='$idvue'");
                    while ($row_vue=mysqli_fetch_assoc($vueres)) {
                      echo "<p class='text-justify'><i class='fas fa-eye mr-2'>&nbsp;&nbsp;".$row_vue['vue']."</i></p>";
                    }

                    ?>
                  </td>
                  <td>
                    <a href="details.php?post=<?php echo $row_pol['displayid'];?>" class="btn btn-secondary">
                      <i class="fas fa-angle-double-right"></i> Détails
                    </a>
                  </td>
                </tr>
              <?php }}?>
              </tbody>
            </table>
          </div>
        </div>
            <!-- PAGINATION -->
            <?php
  // display the links to page
      echo "
      <nav aria-label='Page navigation example mt-2' id='center'>
      <ul class='pagination'>";
      if ($previous != 0) {
      echo '<li class="page-item"><a class="page-link" href="posts.php?page='.$previous.'">'."<i class='fas fa-backward'></i>".'</a></li>';
       }
      for ($page=1; $page<=$number_of_pages ; $page++) { 
        if ($current != $page) {
         echo '<li class="page-item "><a class="page-link" href="posts.php?page='.$page.'">'.$page.'</a></li>'; 
        }else{
        echo '<li class="page-item bg-primary"><a class="page-link bg-primary text-white"  href="posts.php?page='.$page.'">'.$page.'</a></li>';
        }
      }
        echo '<li class="page-item "><a class="page-link" href="posts.php?page='.$next.'">'."<i class='fas fa-forward text-dark'></i>".'</a></li>';
      echo "
      </ul>
      </nav>";
  ?>          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="main-footer" class="text-white mt-5 p-2" style="background-color: rgb(11,12,38);">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">
            Copyright &copy;
            <span id="year"></span>
            SOSOYAMBOKA
          </p>
        </div>
      </div>
    </div>
  </footer>
  <!-- End of footer -->

  <!-- MODALS -->

  <!-- ADD POST MODAL -->
  <div class="modal fade" id="addPostModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title">Ajoute publication</h5>
          <button class="close" data-dismiss="modal">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post" enctype="multipart/form-data">
            <div class="form-group">
              <label for="title">Titre</label>
              <input type="text" class="form-control" name="titre">
            </div>
            <div class="form-group">
              <label for="category">Categorie</label>
              <select class="form-control text-dark" name="categorie">
              <option></option>
              <?php 
               $sql_c = "select * from tbl_categorie";
               $res_c = mysqli_query($con, $sql_c) or die('Hello here');
               while ($row_show = mysqli_fetch_assoc($res_c)){?>
              
                <option><?php echo $row_show['categorie'];?></option>
                <?php }?>
              </select>
            </div>
            <div class="form-group">
              <label for="image">télécharger une image</label>
              <div class="custom-file">
                <label for="image" class="custom-file-label">Choose File</label>
                <input type="file" name="image" class="custom-file-input" id="image"  onchange="loadFile(event)" onclick="showimage()">
                
              </div>
              <small class="form-text text-muted">Max Capacité 3mb</small>
            </div>
            <!-- Show image before upload into the server -->
            <div class="w-100 h-25" style="height: 250px;">
              <img id="imageloader" alt="" width="654" height="490" style="display: none;border:1px solid lightgray;border-radius: 5px;">
            </div>
            <div class="form-group">
              <label for="body">information</label>
              <textarea name="editor1" class="form-control"></textarea>
            </div>
            <div class="form-group">
              <button type="submit" name="publication" class="btn btn-primary">Publie</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- ADD Video MODAL -->
  <div class="modal fade" id="addVideoModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title">Ajoute Media</h5>
          <button class="close" data-dismiss="modal">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post" enctype="multipart/form-data">
            <div class="form-group">
              <label for="title">Titre</label>
              <input type="text" class="form-control" name="titre">
            </div>
            <div class="form-group">
              <label for="category">Categorie</label>
              <select class="form-control text-dark" name="categorie">
              <option></option>
              <?php 

               $sql_c = "select * from tbl_categorie";
               $res_c = mysqli_query($con, $sql_c) or die('Hello here');
               while ($row_show = mysqli_fetch_assoc($res_c)){?>
              
                <option><?php echo $row_show['categorie'];?></option>
                <?php }?>
              </select>
            </div>
            <div class="form-group">
              <label for="image">télécharger une video ou audio</label>
              <div class="custom-file">
                <label for="image" class="custom-file-label">Choisir media</label>
                <input type="file" name="image" class="custom-file-input" id="image"  onchange="loadVideo(event)" onclick="showvideo()">
                
              </div>
              <small class="form-text text-muted">Max Capacité 3mb</small>
            </div>

            <div class="w-100 h-25" style="height: 250px;">
              <video id="videoloader" alt="" width="654" height="490" style="display: none;border:1px solid lightgray;border-radius: 5px;" controls>
              </video>
            </div>
            <div class="form-group">
              <button type="submit" name="media" class="btn btn-primary">Publie</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
  <!-- Active link per page -->
  <script>
      element = document.getElementById('post-link');
      element.classList.add("active")
    </script>
    <!-- End of active link -->


  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>
  <script>
   CKEDITOR.replace('editor1'); 
  </script>
  
    <script>    
   function showimage(){
     var img = document.querySelector('#imageloader');
     img.style.display = 'inline-block'; 
    }
      var loadFile = function(event){
        var image = document.querySelector('#imageloader');
        image.src = URL.createObjectURL(event.target.files[0]);
      };
      function showvideo(){
     var img = document.querySelector('#videoloader');
     img.style.display = 'block'; 
    }
      var loadVideo = function(event){
        var image = document.querySelector('#videoloader');
        image.src = URL.createObjectURL(event.target.files[0]);
      };
    </script>


  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());
  </script>
</body>
</html>
<?php
 if (isset($_POST['publication'])) {
   $titre = mysqli_escape_string($con, $_POST['titre']);
   $categorie = mysqli_escape_string($con, $_POST['categorie']);
  $message = mysqli_escape_string($con, $_POST['editor1']);
  //Image loader
  if (isset($_FILES['image'])) {
     $file_name = $_FILES['image']['name'];
     $file_type = $_FILES['image']['type'];
     $file_error = $_FILES['image']['error'];
     $file_size = $_FILES['image']['size'];
     $file_tmp = $_FILES['image']['tmp_name'];
    }
    //checking for file extension
    if ($file_error === 0){
      switch ($file_type) {
      case 'image/png':
      $exten = '.png';
      break;
      case 'image/jpg':
      $exten = '.jpg';
      break;
      case 'image/jpeg':
      $exten = '.jpeg';
      break;
      case 'image/gif':
      $exten = '.gif';
      break;
    }
  }

  //checking if user already exist inside the database
   $sql_p = "select * from tbl_news where title='$titre'";
   $res_p = mysqli_query($con, $sql_p);
   //End of user checking
   if (empty($titre)) {
     echo '<script>alert("Pardon entre titre")</script>';
   }
    elseif (mysqli_num_rows($res_p) > 0) {
    echo '<script>alert("Pardon titre est deja enregistre")</script>'; 
   }
   elseif (empty($message)) {
     echo '<script>alert("Pardon entre message")</script>';
   }
   else{
     
    
    $path = '../images/news';
    $time = date('h:m:s');
    $displayid = md5($time);
    $imagename = md5($time);
    $pathname = $path.'/'.$imagename.$exten;
    if (isset($_FILES['image'])) {
     echo $pathname; 
    }
    $date = date('Y-m-d h:m:s');
    $path = 'images/news/'.$imagename.$exten;
    $vue = "insert into viewpost(displayid,vue) values('$displayid',0)";
    $sql_post = "insert into tbl_news(title,message,type_of_info,image,infodate,displayid) values('$titre','$message','$categorie','$path','$date','$displayid')";

    if(move_uploaded_file($file_tmp, $pathname)){
      mysqli_query($con, $sql_post);
      mysqli_query($con, $vue);
   echo "<script>
        alert('Publication est enregistre avec success');
        document.getElementById('myform').reset();
        window.location = 'index.php';

        </script>";
   }else{
    echo "<script>alert('Publication n\'est enregistre')</script>";
   }
 }
    }
 ?>

 <?php
 if (isset($_POST['media'])) {
   $titre = mysqli_escape_string($con, $_POST['titre']);
   $categorie = mysqli_escape_string($con, $_POST['categorie']);
  //Image loader
  if (isset($_FILES['image'])) {
     $file_name = $_FILES['image']['name'];
     $file_type = $_FILES['image']['type'];
     $file_error = $_FILES['image']['error'];
     $file_size = $_FILES['image']['size'];
     $file_tmp = $_FILES['image']['tmp_name'];
    }
    //checking for file extension
    /*
    if ($file_error === 0){
      switch ($file_type) {
      case 'image/png':
      $exten = '.png';
      break;
      case 'image/jpg':
      $exten = '.jpg';
      break;
      case 'image/jpeg':
      $exten = '.jpeg';
      break;
      case 'image/gif':
      $exten = '.gif';
      break;
    }
  }
  */

  //checking if user already exist inside the database
   $sql_p = "select * from tbl_newsmedia where title='$titre'";
   $res_p = mysqli_query($con, $sql_p);
   //End of user checking
   if (empty($titre)) {
     echo '<script>alert("Pardon entre titre")</script>';
   }
    elseif (mysqli_num_rows($res_p) > 0) {
    echo '<script>alert("Pardon titre est deja enregistre")</script>'; 
   }
   else{
     
    
    $path = '../images/news';
    $dateMedia = date('Y-m-d');
    $time = date('h:m:s');
    $displayid = md5($time);
    $imagename = md5($time);
    $pathname = $path.'/'.$file_name;
    
    $date = date('Y-m-d h:m:s');
    $path = 'images/news/'.$file_name;
    /*
    $vue = "insert into viewpost(displayid,vue) values('$displayid',0)";
    */
    $sql_post = "insert into tbl_newsmedia(title,type_of_info,media,displayid,infodate) values('$titre','$categorie','$path','$displayid','$dateMedia')";

    if(move_uploaded_file($file_tmp, $pathname)){
      mysqli_query($con, $sql_post);
   echo "<script>
        alert('Media est enregistre avec success');
        document.getElementById('myform').reset();
        window.location = 'posts.php';

        </script>";
   }else{
    echo "<script>alert('Media n\'est enregistre')</script>";
   }
 }
    }
 ?>
