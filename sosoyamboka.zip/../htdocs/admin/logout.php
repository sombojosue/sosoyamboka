<?php
session_start();
//destroy user information
session_destroy();
unset($user_nom);
header("location: ../login.php");

?>