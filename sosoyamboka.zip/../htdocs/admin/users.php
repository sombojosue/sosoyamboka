<?php
include_once('header.php');
include_once('menu.php');
?>  <!-- HEADER -->
  <header id="main-header" class="py-2 bg-warning text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h4>
            <i class="fas fa-users"></i> Utilisateur</h4>
        </div>
      </div>
    </div>
  </header>

  <!-- SEARCH -->
  <section id="search" class="py-4 mb-4 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-6 ml-auto">
          
        </form>
        </div>
      </div>
    </div>
  </section>

  <!-- USERS -->
  <section id="users">
    <div class="container">
      <div class="row">
        <div class="col">
          <div class="card">
            <div class="card-header">
              <h4>Utilisateur</h4>
            </div>
            <table class="table table-striped">
              <thead class="thead-dark">
                <tr>
                  <th>#</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Date de creation</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php 

              require('../includes/db_config.php');
            //Function to return only 100 charactere
            function charlimit($string, $limit) {
            return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
            } 

        $sql_pol = "SELECT * FROM tbl_user  ORDER BY createdate DESC LIMIT 10 ";
        
       $id = 1;
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol)) {
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>

                <tr>
                  <td><?php echo $id++;?></td>
                  <td><h6><?php echo charlimit($row_pol['name'], 30);?></h6></td>
                  <td><?php echo ($row_pol['email']);?></td>
                  <td><?php echo $row_pol['createdate'];?></td>
                </tr>
              <?php }}?>
               </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </section>

  <footer id="main-footer" class="text-white mt-5 p-3" style="background-color: rgb(11,12,38);position: absolute;bottom: 0;width: 100%;">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">
            Copyright &copy;
            <span id="year"></span>
            SOSOYAMBOKA
          </p>
        </div>
      </div>
    </div>
  </footer>

  <!-- Active link per page -->
    <script>
      element = document.getElementById('user');
      element.classList.add("active")
    </script>
    <!-- End of active link -->


  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>


  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());
  </script>
</body>

</html>