<?php
include_once('header.php');
include_once('menu.php');
?>
  <!-- HEADER -->
  <header id="main-header" class="py-2 bg-primary text-white">
    <div class="container">
      <div class="row">
        <div class="col-md-9">
          <h4>
            <i class="fas fa-bell"></i> Publicité</h4>
        </div> 
        <div class="col-md-3">
          <a href="#" class="btn btn-danger btn-block" data-toggle="modal" data-target="#addPostModal">
            <i class="fas fa-plus"></i> Ajouter Publicité
          </a>
        </div>     
      </div>
    </div>
  </header>

  <!-- SEARCH -->
  <section id="search" class="py-4 mb-4 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-6 ml-auto">
          <form method="post" action="research.php" style="visibility: hidden;">
          <div class="input-group">
            <input type="text" class="form-control" placeholder="Cherche Publicité..." name="input" autocomplete="off">
            <div class="input-group-append">
              <button class="btn btn-primary" name="search" type="submit"><i class="fas fa-search"></i></button>
            </div>
          </div>
        </form>
        </div>
      </div>
    </div>
  </section>

  <!-- POSTS -->
  <section id="posts">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-header">
              <h4>Dernières publicité</h4>
            </div>
            <table class="table table-striped">
              <thead class="thead-dark">
                <tr>
                  <th>#</th>
                  <th>Titre</th>
                  <th>Publication</th>
                  <th>Date</th>
                  <th>Vue</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php 

              require('../includes/db_config.php');
              //define how many result per page 
       $number_per_page = 25;
       //find out the number of result stored in databases
        $sql = "select * from tbl_pub";
       $res = mysqli_query($con, $sql);
       $number_of_results = mysqli_num_rows($res);

       // determine number of total result
       $number_of_pages = ceil($number_of_results/$number_per_page);
       //determine which page number the visitor is currently on
       if (!isset($_GET['page'])) {
          $page = 1;
        } else{
          $page = $_GET['page'];
        }
        $current = $page;
        $previous = $page - 1;
        $next = $page + 1;
        //determine the sql  LIMIT number
        $this_page_first_result = ($page - 1) * $number_per_page; 
        //retrive data from mysql database
        
        $sql_pol = "SELECT * FROM tbl_pub ORDER BY pubdate DESC LIMIT " . $this_page_first_result .",".$number_per_page;
       
            //Function to return only 100 charactere
            function charlimit($string, $limit) {
            return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
            } 
        
       $id = 1;
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol)) {
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>

                <tr>
                  <td><?php echo $id++;?></td>
                  <td><h6><?php echo charlimit($row_pol['title'], 30);?></h6></td>
                  <td><?php echo charlimit($row_pol['message'], 90);?></td>
                  <td><?php echo $row_pol['pubdate'];?></td>
                  <!-- Get number of people that watch our news -->
                  <td>
                   <span><i class='fas fa-eye'></i><?php echo $row_pol['vue'];?></span>
                  </td>
                  <td>
                    <a href="details.php?pub=<?php echo $row_pol['displayid'];?>" class="btn btn-secondary">
                      <i class="fas fa-angle-double-right"></i> Détails
                    </a>
                  </td>
                </tr>
              <?php }}?>
              </tbody>
            </table>
          </div>
        </div>
            <!-- PAGINATION -->
            <?php
  // display the links to page
      echo "
      <nav aria-label='Page navigation example mt-2' id='center'>
      <ul class='pagination'>";
      if ($previous != 0) {
      echo '<li class="page-item"><a class="page-link" href="posts.php?page='.$previous.'">'."<i class='fas fa-backward'></i>".'</a></li>';
       }
      for ($page=1; $page<=$number_of_pages ; $page++) { 
        if ($current != $page) {
         echo '<li class="page-item "><a class="page-link" href="posts.php?page='.$page.'">'.$page.'</a></li>'; 
        }else{
        echo '<li class="page-item bg-primary"><a class="page-link bg-primary text-white"  href="posts.php?page='.$page.'">'.$page.'</a></li>';
        }
      }
        echo '<li class="page-item "><a class="page-link" href="posts.php?page='.$next.'">'."<i class='fas fa-forward text-dark'></i>".'</a></li>';
      echo "
      </ul>
      </nav>";
  ?>          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="main-footer" class="text-white mt-5 p-2" style="background-color: rgb(11,12,38);">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">
            Copyright &copy;
            <span id="year"></span>
            SOSOYAMBOKA
          </p>
        </div>
      </div>
    </div>
  </footer>
  <!-- End of footer -->

  <!-- MODALS -->

  <!-- ADD POST MODAL -->
  <div class="modal fade" id="addPostModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title">Ajoute publicite</h5>
          <button class="close" data-dismiss="modal">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post" enctype="multipart/form-data">
            <div class="form-group">
              <label for="title">Titre</label>
              <input type="text" class="form-control" name="titre">
            </div>
            <div class="form-group">
              <label for="title">Limit date</label>
              <input type="date" class="form-control" name="lastdate">
            </div>
            <div class="form-group">
              <label for="image">télécharger une image</label>
              <div class="custom-file">
                <label for="image" class="custom-file-label">Choose File</label>
                <input type="file" name="image" class="custom-file-input" id="image"  onchange="loadFile(event)" onclick="showimage()">
                
              </div>
              <small class="form-text text-muted">Max Capacité 3mb</small>
            </div>
            <!-- Show image before upload into the server -->
            <div class="w-100 h-25" style="height: 250px;">
              <img id="imageloader" alt="" width="654" height="490" style="display: none;border:1px solid lightgray;border-radius: 5px;">
            </div>
            <div class="form-group">
              <label for="body">information</label>
              <textarea name="editor1" class="form-control"></textarea>
            </div>
            <div class="form-group">
              <button type="submit" name="publication" class="btn btn-primary">Publie</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script>
      element = document.getElementById('pub');
      element.classList.add("active")
    </script>
    <!-- End of active link -->


  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  <script>
    function showimage(){
     var img = document.querySelector('#imageloader');
     img.style.display = 'inline-block'; 
    }
      var loadFile = function(event){
        var image = document.querySelector('#imageloader');
        image.src = URL.createObjectURL(event.target.files[0]);
      };
    </script>


  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());
  </script>
</body>
</html>
<?php
 if (isset($_POST['publication'])) {
   $titre = mysqli_escape_string($con, $_POST['titre']);

   $last = mysqli_escape_string($con, $_POST['lastdate']);
   $message = mysqli_escape_string($con, $_POST['editor1']);
  //Image loader
  if (isset($_FILES['image'])) {
     $file_name = $_FILES['image']['name'];
     $file_type = $_FILES['image']['type'];
     $file_error = $_FILES['image']['error'];
     $file_size = $_FILES['image']['size'];
     $file_tmp = $_FILES['image']['tmp_name'];
    }
    //checking for file extension
    if ($file_error === 0){
      switch ($file_type) {
      case 'image/png':
      $exten = '.png';
      break;
      case 'image/jpg':
      $exten = '.jpg';
      break;
      case 'image/jpeg':
      $exten = '.jpeg';
      break;
      case 'image/gif':
      $exten = '.gif';
      break;
    }
  }

  //checking if user already exist inside the database
   $sql_p = "select * from tbl_pub where title='$titre'";
   $res_p = mysqli_query($con, $sql_p);
   //End of user checking
   if (empty($titre)) {
     echo '<script>alert("Pardon entre titre")</script>';
   }
    elseif (mysqli_num_rows($res_p) > 0) {
    echo '<script>alert("Pardon titre est deja enregistre")</script>'; 
   }
   elseif (empty($message)) {
     echo '<script>alert("Pardon entre message")</script>';
   }
   else{
     
    
    $path = '../images/news';
    $time = date('h:m:s');
    $displayid = md5($time);
    $imagename = md5($time);
    $pathname = $path.'/'.$imagename.$exten;
    
    $date = date('Y-m-d h:m:s');
    $path = 'images/news/'.$imagename.$exten;
    
    $sql_post = "insert into tbl_pub(title,message,image,pubdate,displayid,lastdate) values('$titre','$message','$path','$date','$displayid','$last')";

    if(move_uploaded_file($file_tmp, $pathname)){
      mysqli_query($con, $sql_post);
      
      echo "<script>
        alert('Publicate est enregistre avec success');
        document.getElementById('myform').reset();
        window.location = 'posts.php';

        </script>";
   }else{
    echo "<script>alert('Publicite n\'est enregistre')</script>";
   }
 }
    }
 ?>

 