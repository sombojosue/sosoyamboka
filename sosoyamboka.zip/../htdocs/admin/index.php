<?php
include_once('header.php');
include_once('menu.php');
?>

  <!-- HEADER -->
  <header id="main-header" class="py-2 text-white" style="background:#f71735 !important;">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <h4>
            <i class="fas fa-cog"></i> Tableau de bord</h4>
        </div>
      </div>
    </div>
  </header>

  <!-- ACTIONS -->
  <section id="actions" class="py-4 mb-4 bg-light">
    <div class="container">
      <div class="row">
        <div class="col-md-3 mb-2">
          <a href="#" class="btn btn-primary btn-block" data-toggle="modal" data-target="#addPostModal">
            <i class="fas fa-plus"></i> Ajouter Publication
          </a>
        </div>
        <div class="col-md-3 mb-2">
          <a href="#" class="btn btn-success btn-block" data-toggle="modal" data-target="#addCategoryModal">
            <i class="fas fa-plus"></i> Ajouter categorie
          </a>
        </div>
        <div class="col-md-3 mb-2">
          <a href="#" class="btn btn-warning btn-block text-white" data-toggle="modal" data-target="#addUserModal">
            <i class="fas fa-plus"></i> Ajouter Utilisateur
          </a>
        </div>
      </div>
    </div>
  </section>

  <!-- POSTS -->
  <section id="posts">
    <div class="container">
      <div class="row">
        <div class="col-md-9">
          <div class="card">
            <div class="card-header">
              <h4>Dernières publications</h4>
            </div>
            <table class="table table-striped">
              <thead class="thead-dark">
                <tr>
                  <th>#</th>
                  <th>Titre</th>
                  <th>Information</th>
                  <th>Date</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php 

              require('../includes/db_config.php');
            //Function to return only 100 charactere
            function charlimit($string, $limit) {
            return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
            } 

        $sql_pol = "SELECT * FROM tbl_news  ORDER BY infodate DESC LIMIT 13 ";
        
       $id = 1;
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol)) {
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>

                <tr>
                  <td><?php echo $id++;?></td>
                  <td><h6><?php echo charlimit($row_pol['title'], 30);?></h6></td>
                  <td><?php echo charlimit($row_pol['message'], 90);?></td>
                  <td><?php echo $row_pol['infodate'];?></td>
                  <td>
                    <a href="details.php?post=<?php echo $row_pol['displayid'];?>" class="btn btn-secondary">
                      <i class="fas fa-angle-double-right"></i> Details
                    </a>
                  </td>
                </tr>
              <?php }}?>
              </tbody>
            </table>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card text-center bg-primary text-white mb-3">
            <div class="card-body">
              <h3>Publication</h3>
              <h4 class="display-4">
                <i class="fas fa-pencil-alt"></i> <strong id="post" class="ml-2"></strong> 
              </h4>
              <a href="posts.php" class="btn btn-outline-light btn-sm">Vue</a>
            </div>
          </div>

          <div class="card text-center bg-secondary text-white mb-3">
            <div class="card-body">
              <h3>Abonnée</h3>
              <h4 class="display-4">
                <i class="fas fa-envelope"></i> 
                <strong id="message" class="ml-2"></strong>
              </h4>
            </div>
          </div>

          <div class="card text-center bg-success text-white mb-3">
            <div class="card-body">
              <h3>Contact</h3>
              <h4 class="display-4">
                <i class="fas fa-address-book"></i> <strong id="contact" class="ml-2"></strong> 
              </h4>
              <a href="contact.php" class="btn btn-outline-light btn-sm">Vue</a>
            </div>
          </div>

          <div class="card text-center bg-warning text-white mb-3">
    <!-- Count the number of users inside the database -->
            <?php 

              require('../includes/db_config.php');

        $sql_user = "SELECT count(id) as val FROM tbl_user";
        
       
       $res_user = mysqli_query($con, $sql_user);
       while ( $row_pol = mysqli_fetch_assoc($res_user)) {
         $numberCount = $row_pol['val']; 
       }?>
            <div class="card-body">
              <h3>Utilisateurs</h3>
              <h4 class="display-4">
                <i class="fas fa-users"></i> <?php echo $numberCount;?>
              </h4>
              <a href="users.php" class="btn btn-outline-light btn-sm">Vue</a>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- FOOTER -->
  <footer id="main-footer" class="text-white mt-5 p-3" style="background-color: rgb(11,12,38);">
    <div class="container">
      <div class="row">
        <div class="col">
          <p class="lead text-center">
            Copyright &copy;
            <span id="year"></span>
            SOSOYAMBOKA
          </p>
        </div>
      </div>
    </div>
  </footer>



  <!-- MODALS -->

  <!-- ADD POST MODAL -->
  <div class="modal fade" id="addPostModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-primary text-white">
          <h5 class="modal-title">Ajoute publication</h5>
          <button class="close" data-dismiss="modal">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post" enctype="multipart/form-data">
            <div class="form-group">
              <label for="title">Titre</label>
              <input type="text" class="form-control" name="titre">
            </div>
            <div class="form-group">
              <label for="category">Categorie</label>
              <select class="form-control text-dark" name="categorie">
              <option></option>
              <?php 
               $sql_c = "select * from tbl_categorie";
               $res_c = mysqli_query($con, $sql_c) or die('Hello here');
               while ($row_show = mysqli_fetch_assoc($res_c)){?>
              
                <option><?php echo $row_show['categorie'];?></option>
                <?php }?>
              </select>
            </div>          
            
            <div class="form-group">
              <label for="image">télécharger une image</label>
              <div class="custom-file">
                <label for="image" class="custom-file-label">Choose File</label>
                <input type="file" name="image" class="custom-file-input" id="image"  onchange="loadFile(event)" onclick="showimage()">
                
              </div>
              <small class="form-text text-muted">Max Capacité 3mb</small>
            </div>
            <!-- Show image before upload into the server -->
            <div class="w-100 h-25" style="height: 250px;">
              <img id="imageloader" alt="" width="654" height="490" style="display: none;border:1px solid lightgray;border-radius: 5px;">
            </div>
            <div class="form-group">
              <label for="body">information</label>
              <textarea name="editor1" class="form-control"></textarea>
            </div>
            <div class="form-group">
              <button type="submit" name="publication" class="btn btn-primary">Publie</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- ADD CATEGORY MODAL -->
  <div class="modal fade" id="addCategoryModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-success text-white">
          <h5 class="modal-title">Ajoute Categorie</h5>
          <button class="close" data-dismiss="modal">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post" id="mydata">
            <div class="form-group">
              <label for="title">Titre</label>
              <input type="text" class="form-control" name="categorie_titre">
            </div>
            <div class="form-group">
              <button type="submit" name="info_type" class="btn btn-success">Ajoute</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <!-- ADD USER MODAL -->
  <div class="modal fade" id="addUserModal">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <div class="modal-header bg-warning text-white">
          <h5 class="modal-title">Ajoute utilisateur</h5>
          <button class="close" data-dismiss="modal">
            <span>&times;</span>
          </button>
        </div>
        <div class="modal-body">
          <form method="post" id="myform">
            <div class="form-group">
              <label for="name">Nom</label>
              <input type="text" class="form-control" name="name">
            </div>
            <div class="form-group">
              <label for="email">Email</label>
              <input type="email" class="form-control" name="email">
            </div>
            <div class="form-group">
              <label for="password">Mot de pass</label>
              <input type="password" class="form-control" name="password1">
            </div>
            <div class="form-group">
              <label for="password2">Confirm Password</label>
              <input type="password" class="form-control" name="password2">
            </div>
            <div class="form-group">
              <button type="submit" name="user" class="btn bg-warning">Ajoute</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<?php
 if (isset($_POST['publication'])) {
   $titre = mysqli_escape_string($con, $_POST['titre']);
   $categorie = mysqli_escape_string($con, $_POST['categorie']);
  $message = mysqli_escape_string($con, $_POST['editor1']);
  //Image loader
  if (isset($_FILES['image'])) {
     $file_name = $_FILES['image']['name'];
     $file_type = $_FILES['image']['type'];
     $file_error = $_FILES['image']['error'];
     $file_size = $_FILES['image']['size'];
     $file_tmp = $_FILES['image']['tmp_name'];
    }
    //checking for file extension
    if ($file_error === 0){
      switch ($file_type) {
      case 'image/png':
      $exten = '.png';
      break;
      case 'image/jpg':
      $exten = '.jpg';
      break;
      case 'image/jpeg':
      $exten = '.jpeg';
      break;
      case 'image/gif':
      $exten = '.gif';
      break;
    }
  }

  //checking if user already exist inside the database
   $sql_p = "select * from tbl_news where title='$titre'";
   $res_p = mysqli_query($con, $sql_p);
   //End of user checking
   if (empty($titre)) {
     echo '<script>alert("Pardon entre titre")</script>';
   }
    elseif (mysqli_num_rows($res_p) > 0) {
    echo '<script>alert("Pardon titre est deja enregistre")</script>'; 
   }
   elseif (empty($message)) {
     echo '<script>alert("Pardon entre message")</script>';
   }
   else{
     
    
    $path = '../images/news';
    $time = date('h:m:s');
    $displayid = md5($time);
    $imagename = md5($time);
    $pathname = $path.'/'.$imagename.$exten;
   
    $date = date('Y-m-d h:m:s');
    $path = 'images/news/'.$imagename.$exten;
    $vue = "insert into viewpost(displayid,vue) values('$displayid',0)";
    $sql_post = "insert into tbl_news(title,message,type_of_info,image,infodate,displayid) values('$titre','$message','$categorie','$path','$date','$displayid')";

    if(move_uploaded_file($file_tmp, $pathname)){
      mysqli_query($con, $sql_post);
      mysqli_query($con, $vue);
   echo "<script>
        alert('Publication est enregistre avec success');
        document.getElementById('myform').reset();
        window.location = 'index.php';

        </script>";
   }else{
    echo "<script>alert('Publication n\'est pas enregistre')</script>";
   }
 }
    }
 ?>

 <?php
 if (isset($_POST['user'])) {
   $name = mysqli_escape_string($con, $_POST['name']);
   $email = mysqli_escape_string($con, $_POST['email']);
   $password1 = mysqli_escape_string($con, $_POST['password1']);
   $password2 = mysqli_escape_string($con, $_POST['password2']);
   //checking if user already exist inside the database
   $sql_u = "select * from tbl_user where email='$email'";
   $res_u = mysqli_query($con, $sql_u);
   //End of user checking
   if (empty($email)) {
     echo '<script>alert("Pardon entre email")</script>';
   }
   elseif (mysqli_num_rows($res_u) > 0) {
    echo '<script>alert("Pardon email est deja enregistre")</script>'; 
   }
   elseif (empty($password1) or empty($password2)) {
     echo '<script>alert("Pardon entre mot de pass")</script>';
   }elseif ($password1 !== $password2) {
     echo '<script>alert("Pardon entre le meme mot de pass")</script>';
   }
    elseif (strlen($password1) < 9) {
     echo '<script>alert("Pardon entre le mot de pass superieur a 7 charactere")</script>';
   }
   else{
    $hashpass = md5($password1);
    $date = date('Y-m-d h:m:s');
    $sql = "insert into tbl_user(name,email,psswd,createdate) values('$name','$email','$hashpass','$date')";
   mysqli_query($con, $sql);
   echo "<script>
        alert('Utilisateur est enregistre avec success');
        document.getElementById('myform').reset();
        window.location = 'index.php';

        </script>";
   }
 }
 ?>

 <?php
 if (isset($_POST['info_type'])) {
   $categorie_titre = mysqli_escape_string($con, $_POST['categorie_titre']);
  
   //checking if user already exist inside the database
   $sql_c = "select * from tbl_categorie where categorie='$categorie_titre'";
   $res_c = mysqli_query($con, $sql_c);
   //End of user checking
   if (empty($categorie_titre)) {
     echo '<script>alert("Pardon entre categorie")</script>';
   }
    elseif (mysqli_num_rows($res_c) > 0) {
    echo '<script>alert("Pardon categorie est deja enregistre")</script>'; 
   }
   else{

    $sql = "insert into tbl_categorie(categorie) values('$categorie_titre')";
   mysqli_query($con, $sql);
   echo "<script>
        alert('Categorie est enregistre avec success');
        document.getElementById('mydata').reset();
        window.location = 'index.php';

        </script>";
   }
 }
 ?>
  <script src="http://code.jquery.com/jquery-3.3.1.min.js" integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
    crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
    crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js" integrity="sha384-smHYKdLADwkXOn1EmN1qk/HfnUcbVRZyYmZ4qpPea6sjB/pTJ0euyQp0Mk8ck+5T"
    crossorigin="anonymous"></script>
  <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>

  <script>
    // Get the current year for the copyright
    $('#year').text(new Date().getFullYear());

    CKEDITOR.replace('editor1');
  </script>

  <script>

     var ajax = new XMLHttpRequest();
     var post = document.getElementById('post');
     var contact = document.getElementById('contact');
     var message = document.getElementById('message');
    // Update notification 
    function info(){
      var url = 'php/postcompte.php';
      ajax.onreadystatechange = notifa;
      ajax.open('POST',url,true);
      ajax.setRequestHeader('Content-Type','application/x-www-form-urlencoder'); //only use in case of POST
      ajax.send('name=josue');

      }
      function notifa(){
            if (ajax.readyState === 4) {
              if (ajax.status === 200) {
                var data = JSON.parse(ajax.responseText);
                post.innerHTML = data;  
              }
            }
      }

function cont(){
      var url = 'php/contactcompte.php';
      ajax.onreadystatechange = conta;
      ajax.open('POST',url,true);
      ajax.setRequestHeader('Content-Type','application/x-www-form-urlencoder'); //only use in case of POST
      ajax.send('name=josue');

      }
      function conta(){
            if (ajax.readyState === 4) {
              if (ajax.status === 200) {
                var data = JSON.parse(ajax.responseText);
                contact.innerHTML = data;  
              }
            }
      }

      function customer(){
      var url = 'php/newslettercompte.php';
      ajax.onreadystatechange = newsletter;
      ajax.open('POST',url,true);
      ajax.setRequestHeader('Content-Type','application/x-www-form-urlencoder'); //only use in case of POST
      ajax.send('name=josue');

      }
      function newsletter(){
            if (ajax.readyState === 4) {
              if (ajax.status === 200) {
                var data = JSON.parse(ajax.responseText);
                message.innerHTML = data;  
              }
            }
      }

      //call the function to run after some times
      setInterval(function(){info()},2400);
      setInterval(function(){customer()},3800);
      setInterval(function(){cont()},4800);
      

  </script>
  <script>
    function showimage(){
     var img = document.querySelector('#imageloader');
     img.style.display = 'inline-block'; 
    }
      var loadFile = function(event){
        var image = document.querySelector('#imageloader');
        image.src = URL.createObjectURL(event.target.files[0]);
      };
    </script>
    <!-- Active link per page -->
    <script>
      element = document.getElementById('home');
      element.classList.add("active")
    </script>
    <!-- End of active link -->
</body>

</html>
