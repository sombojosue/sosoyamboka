<?php 
  //Timeframe
  $date_time_now = date("Y-m-d H:i:s");
  $start_date = new DateTime($date_time);
  $end_date = new DateTime($date_time_now);
  $interval = $start_date->diff($end_date);
  if ($interval->y >= 1) {
    $interval = $interval." années";
  }
  if ($interval->m >= 1) {
    if ($interval == 1) {
       $time_message = $interval->y. "ans passer"; //1 year 
    }else{
       $time_message = $interval->y. "années passer"; //1+ years
    }
  }
  elseif ($interval-> m >= 1) {
    if ($interval->d == 0) {
      $days = " passer";
    }
    elseif ($interval->d == 1) {
      $days = $interval->d. "jour passer";
    }
    else{
      $days = $interval->d. "jours passer";
    }

    if ($interval->m == 1) {
      $time_message = $interval->m. " mois". $days;
    }else{
      $time_message = $interval->m. " mois". $days;
    }
  }
  elseif ($interval->d >= 1) {
    if ($interval->d == 1) {
      $time_message = "Hier";
    }
    else{
      $time_message = $interval->d. " jours passer";
    }
  }
  elseif ($interval->h >= 1) {
    if ($interval->h == 1) {
      $time_message = $interval->h. " hr passer";
    }
    else{
      $time_message = $interval->h. " hrs  passer";
    }
  }
  elseif ($interval->i >= 1) {
    if ($interval->i == 1) {
      $time_message = $interval->i. " min passer";
    }
    else{
      $time_message = $interval->i. " mins  passer";
    }
  }
  else {
    if ($interval->s < 30) {
      $time_message = " Juste maintenant";
    }
    else{
      $time_message = $interval->s. " secs  passer";
    }
  }?>