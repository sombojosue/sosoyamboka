<?php

require('db_config.php');
//Function to return only 100 charactere
function charlimit($string, $limit) {
return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
} 
//Fin de function
       //define how many result per page 
       $number_per_page = 20;
       //find out the number of result stored in databases
        $sql = "select * from tbl_news where type_of_info ='sante'";
       $res = mysqli_query($con, $sql);
       $number_of_results = mysqli_num_rows($res);

       // determine number of total result
       $number_of_pages = ceil($number_of_results/$number_per_page);
       //determine which page number the visitor is currently on
       if (!isset($_GET['page'])) {
          $page = 1;
        } else{
          $page = $_GET['page'];
        }
        $current = $page;
        $previous = $page - 1;
        $next = $page + 1;
        //determine the sql  LIMIT number
        $this_page_first_result = ($page - 1) * $number_per_page; 
        //retrive data from mysql database
        
        $sql_pol = "SELECT * FROM tbl_news where type_of_info='sante' ORDER BY infodate DESC LIMIT " . $this_page_first_result .",".$number_per_page;
        

	//$sql_pol = "select * from tbl_news where type_of_info='politique'";
	$res_pol = mysqli_query($con, $sql_pol);
	if (mysqli_num_rows($res_pol)) {
	while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>
	 
	<div class="col-xs-12 col-sm-2 col-md-4 col-lg-3 poli mb-3">
	    <div class="card_news">
	    <a href="sante.php?info=<?php echo $row_pol['displayid'];?>">
	    <img src="<?php echo $row_pol['image'];?>" alt="<?php echo $row_pol['title'];?>" style="width:100%">
	    <div class="container_news">
	    <h5 class="post-title featured-title text-left" style="margin: 0;font-size: 19px;line-height: 28px;"><b><?php echo charlimit($row_pol['title'], 120);?></b></h5>
	    	   </div>
	      </a>
	       </div>    
	        </div>
	<?php }}?>

	
