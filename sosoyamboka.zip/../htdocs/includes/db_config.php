<?php
//set a default time zone for kinshasa
date_default_timezone_set("Africa/Kinshasa");

//create user information to login into the database

$userAccount = 'root';
$passAccount = '8ti6AKoeLDvk';
$host = 'localhost';
$db_name = 'sosoyamboka_db';

$con = mysqli_connect($host, $userAccount, $passAccount, $db_name);


//query for auto-complite page
$search = "select title from tbl_news";
$codesearch = array();
$query_search = mysqli_query($con, $search);
while ($row = mysqli_fetch_array($query_search)) {
	$codesearch[] = $row['title'];
 }
//End of query search

?>
