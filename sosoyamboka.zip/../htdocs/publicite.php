<?php 
include_once('header.php');
include_once('menu.php');
?>

<?php
$search = '';
//checking if detail link is cleked
if (isset($_GET['info'])) {
  $search = $_GET['info'];
  $sql_pol = "select * from tbl_pub where displayid='$search'";
  $res_pol = mysqli_query($con, $sql_pol);
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {
    $image = $row_pol['image'];
    $title = $row_pol['title'];
    $message = $row_pol['message'];
    $date = $row_pol['pubdate'];
  }
  $date_time = $date;
  include_once('includes/datetime.php');
  //sending number of view into the databases system
  $sql_view = "select vue from  viewpost where displayid='$search'";
  $res_view = mysqli_query($con, $sql_view);

while($res_query=mysqli_fetch_assoc($res_view)) {
  $count = $res_query['vue'];
  $numberCode = (int)$count + 1;
  mysqli_query($con, "update viewpost set vue='$numberCode' where displayid='$search'");
}
//end of sending database information 
}
?>
    <!-- page-title -->
    <div class="ttm-page-title-row" style="background-image: url('images/pub.png');">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-box ttm-textcolor-white">
              <div class="page-title-heading">
                <!-- Change title when detail is clicked --></div><!-- /.page-title-captions -->
              <div class="breadcrumb-wrapper">             </div>
            </div>
          </div><!-- /.col-md-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </div>
  <!-- page-title end-->
    <!--site-main start-->
    <!-- Display data into the server -->
    <?php
    if ($search !== '') {
     echo "
          <div class='displaydetail container-fluid'>
          <section class='container mt-3 mb-3'>
          <h2 class='title' style='width:5.6%;font-size:1.5rem;border-bottom: 2px solid red;opacity:0.6' id='poli'>Publicite
          </h2>

          <div class='row'>
          <div class='col-xs-12 col-sm-8 col-md-6 col-lg-6 rightdetail'>
          <h3 style='font-size: 1.5rem;line-height:1.16667;color: #1e1e1e;font-weight: bold;'>$title</h3>
          <p class='mt-2'>Par sosoyamboka</p>
          <p><img src='images/watch.png' width='22' height='22' class='mr-1' style='position:relative;bottom:4px;'>$time_message</p>
          <hr>
          <img src='$image' style='width:100%;margin-bottom:8px;'>
          <p class='mt-2'>$message</p>
          
          </div>
          <div class='col-xs-12 col-sm-4 col-md-4 col-lg-4'>
          <div class='w-100'>
           <h4 class='ml-3'>Nos dernières actualités</h4>
           <hr class='ml-3 mr-3'>
          </div>
          <div id='dataShow'>
          <script type='text/javascript'>
            
        messageGet = document.getElementById('dataShow');
             
        function Showmessage() {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function() {
          if (this.readyState == 4 && this.status == 200) {
            messageGet.innerHTML = this.responseText;
            }
         };
        xhttp.open('POST', 'ajax/pubShow.php', true);
        xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
        xhttp.send(); 
      }
      //Showmessage()
      setInterval(function(){Showmessage()},21000);

            </script>
          </div>
          </div>
          </div>
          </section>
          </div>
          <br>
          <br>
          ";
    }else{?>
    <div class="site-main" style="padding-top: 0px;" id="poli">

      <!-- Politique -->
      <section class="ttm-row blog-text-section ttm-bgcolor-grey mt_120 res-991-mt-0 clearfix" style="margin-bottom: 0px !important;">
        <div class="container">
        <!-- row -->
          <div class="row">
            <div class="col-lg-12 col-md-12">
              <!-- section-title -->
              <div class="section-title style2 clearfix">
                <div class="title-header">
                  <h2 class="title politique" style="border-left: 4.2px #c3ffff solid;">Publicite</h2>
                </div>
              <hr>
              </div><!-- section-title end -->
            </div>
          </div>
        <!-- row end -->
        
        <!-- Getting data from mysql server -->
        <div class="row">
        <!-- Start of the first politique news --> 
        <?php
        include('includes/showdata-pub.php');
        ?>
       </div>
       <!-- End of politique -->
        <?php
  // display the links to page
      echo "
      <nav aria-label='Page navigation example mt-2' id='center'>
      <ul class='pagination'>";
      if ($previous != 0) {
      echo '<li class="page-item"><a class="page-link" href="publicite.php?page='.$previous.'">'."<i class='fas fa-backward'></i>".'</a></li>';
       }
      for ($page=1; $page<=$number_of_pages ; $page++) { 
        if ($current != $page) {
         echo '<li class="page-item"><a class="page-link" href="publicite.php?page='.$page.'">'.$page.'</a></li>'; 
        }else{
        echo '<li class="page-item bg-white"><a class="page-link pagi-link text-white"  href="publicite.php?page='.$page.'">'.$page.'</a></li>';
        }
      }
        echo '<li class="page-item "><a class="page-link" href="publicite.php?page='.$next.'">'."<i class='fas fa-forward text-dark'></i>".'</a></li>';
      echo "
      </ul>
      </nav>";
  ?>
      </div>
      </section>
      <!--blog-text-section end-->

    </div>
    <!--site-main end-->
  <?php }?>

  <!-- Active link per page -->
    <script>
      element = document.getElementById('pub');
      element.classList.add("active")
    </script>
    <!-- End of active link -->

    <?php 
    include_once('footer.php');
    ?>