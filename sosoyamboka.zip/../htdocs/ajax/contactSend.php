<!-- Send message into the mysql databases -->
     <?php 
     require('../includes/db_config.php');

    $name = mysqli_real_escape_string($con, $_POST['name']);
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $subject = mysqli_real_escape_string($con, $_POST['subject']);
    $message = mysqli_real_escape_string($con, $_POST['message']);

     
     $date = date("Y-m-d H:i:s");
     
     $query = mysqli_query($con, "insert into contact(name,email,subject,message,contactdate) values('$name','$email','$subject','$message','$date')");
     //if sending success
     if ($query) {
       echo "Votre message a ete envoye avec success";
     }  
     ?>
     <!-- End of Sending message into the mysql databases -->
