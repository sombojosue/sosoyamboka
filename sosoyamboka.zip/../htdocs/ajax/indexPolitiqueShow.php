<?php

require('includes/db_config.php');
//Function to return only 100 charactere
function charlimit($string, $limit) {
return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
} 

        
$sql_pol = "SELECT title,image,infodate,displayid FROM tbl_news  ORDER BY infodate DESC LIMIT 28";
        
  $res_pol = mysqli_query($con, $sql_pol);
  if (mysqli_num_rows($res_pol)) {
  while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>
   
  <div class="col-xs-12 col-sm-2 col-md-4 col-lg-3 poli mb-3">
      <div class="card_news" style="position: relative;">

      <a href="article.php?info=<?php echo $row_pol['displayid'];?>">
        <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-background-color-skincolor ttm-icon_element-size-xs" style="position: absolute;top: 0;right: 0;">
        <i class="fa fa-book-open"></i>
        </div>
      <img src="<?php echo $row_pol['image'];?>" alt="<?php echo $row_pol['title'];?>" style="width:100%">
      <div class="container_news">
      <h5 class="post-title featured-title text-left" style="margin: 0;font-size: 19px;line-height: 28px;"><b><?php echo charlimit($row_pol['title'], 110);?></b></h5>
      <br>
      <br>
      <br>
      <strong><?php echo $row_pol['infodate'];?></p></strong>  
     </div>
        </a>
         </div>    
          </div>
  <?php }}?>

  
