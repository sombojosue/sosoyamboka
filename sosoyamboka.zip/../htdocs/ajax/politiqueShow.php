<?php

require('../includes/db_config.php');

$sql_pol = "SELECT * FROM tbl_news where type_of_info='politique' ORDER BY infodate DESC LIMIT 5 ";
        

	//$sql_pol = "select * from tbl_news where type_of_info='politique'";
	$res_pol = mysqli_query($con, $sql_pol);
	if (mysqli_num_rows($res_pol)) {
	while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>
	 
	<div class="col-xs-12 col-sm-12 col-md-11 col-lg-11" style="margin-bottom: 8px;">
	    <div class="card_news" id="reduice">
	    <a href="article.php?info=<?php echo $row_pol['displayid'];?>">
	    <img src="<?php echo $row_pol['image'];?>" alt="<?php echo $row_pol['title'];?>" style="width:100%;height: 170px;border-radius: 5px;">
	    <div class="container_news">
	    <h2 class="display-2 mt-2 text-left" style="text-align: center;font-size: 1rem;"><b><?php echo $row_pol['title'];?></b></h2>  
	   </div>
	      </a>
	       </div>    
	        </div>
	<?php }}?>

	
