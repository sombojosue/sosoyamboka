<!--Politique-section-->
      <section class="ttm-row about-blog-section clearfix">
        <div class="container">
          <!-- row -->
          <div class="row">
          <?php 

          require('includes/db_config.php');

        $sql_pol = "SELECT * FROM tbl_newsmedia order by infodate desc Limit 20";
        
       
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol) > 0) {
       echo '<div style="width: 100%;height: 109px;">
     <div class="container mb-2">
       <div class="row">
          <div class="col-xs-12 col-sm-12 col-md-12">
             <h2>Vidéos</h2>
             <hr>
          </div>
       </div>
     </div> 
    </div>';
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>
      <div class="col-xs-9 col-sm-6 col-md-3 col-lg-3" style="position: relative;">        
      <div class="card mb-2">
  
      <video controls controlsList="nofullscreen nodownload" src="<?php echo $row_pol['media'];?>" preload="none" style='object-fit: cover;width: 100%;height: 262px;border-bottom: 1px solid lightgray;opacity: .7;' poster="images/imgposter.png"> </video>
        <h5 class="ml-1 text-left" style="font-size: 23px;position: absolute;top: 5%;color:#fff;display: block;"><?php echo $row_pol['title'];?></h5>
        
              </div>
            </div>
              <!-- featured-imagebox-post end -->
              <!-- featured-imagebox-post -->
            <?php }}?>
            </div>
          <!-- row end-->
        </div>
      </section>
      <!--Politique-section end-->
