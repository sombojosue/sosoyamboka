<!-- Send message into the mysql databases -->
     <?php 
     require('../includes/db_config.php');

    
    $email = mysqli_real_escape_string($con, $_POST['email']);
     
     $date = date("Y-m-d H:i:s");
     //check if email id already existe inside the server
     $sql = "select * from subscribe where email='$email'";
     $res = mysqli_query($con, $sql);
     if (mysqli_num_rows($res) > 0) {
        echo "Vous avez ete enregistre :)";
     }
     else
     {     
     $query = mysqli_query($con, "insert into subscribe(email,datesubscribe) values('$email','$date')");
     //if sending success
     if ($query) {
       echo "Merci d'étre enregistre";
     }
     }  
     ?>
     <!-- End of Sending message into the mysql databases -->
