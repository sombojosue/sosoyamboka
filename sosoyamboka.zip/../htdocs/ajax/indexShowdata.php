<!--Politique-section-->
      <section class="ttm-row about-blog-section clearfix">
        <div class="container">
          <!-- row -->
          <div class="row">
            <!-- post-slide -->
            <div class="post-slide owl-carousel owl-theme owl-loaded " data-item="4" data-nav="false" data-dots="false" data-auto="false">
              <!-- featured-imagebox-post -->
              <?php 

              require('includes/db_config.php');

        $sql_pol = "SELECT * FROM tbl_news where type_of_info='politique' ORDER BY infodate DESC LIMIT 8 ";
        
       //Function to return only 100 charactere
        function charlimiter($string, $limit) {
        return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
        }
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol)) {
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>
              <div class="featured-imagebox featured-imagebox-post box-shadow">
                <div class="featured-thumbnail">
                  <img class="img-fluid" src="<?php echo $row_pol['image'];?>" alt="news">
                  <div class="featured-icon">
                    <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-background-color-skincolor ttm-icon_element-size-xs">
                      <i class="fab fa-readme"></i>
                    </div>
                  </div>
                </div>
                <div class="featured-content featured-content-post">
                  <div class="post-title featured-title">
                    <h5 class="text-left" style="font-size: 18px;"><a href="culture.php?info=<?php echo $row_pol['displayid'];?>"><?php echo charlimiter($row_pol['title'], 60);?></a></h5>
                  </div>
                   
                  <div class="post-meta">
                    <span class="ttm-meta-line"><i class="fa fa-calendar"></i><?php echo $row_pol['infodate'];?></span>
                  </div>
                </div>
              </div>
              <!-- featured-imagebox-post end -->
              <!-- featured-imagebox-post -->
            <?php }}?>
            </div>
          </div><!-- row end-->
        </div>
      </section>
      <!--Politique-section end-->

  