<?php 
include_once('header.php');
include_once('menu.php');
?>
    <!-- page-title -->
    <div class="ttm-page-title-row">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="title-box ttm-textcolor-white">
              <div class="page-title-heading">
                <h1 class="title">A propos de nous</h1>
              </div><!-- /.page-title-captions -->
              <div class="breadcrumb-wrapper">
                <span>
                  <a title="Homepage" href="index.html"><i class="ti ti-home"></i>&nbsp;&nbsp;Accueil</a>
                </span>
                <span class="ttm-bread-sep">&nbsp; | &nbsp;</span>
                <span>A propos</span>
              </div>
            </div>
          </div><!-- /.col-md-12 -->
        </div><!-- /.row -->
      </div><!-- /.container -->
    </div>
  <!-- page-title end-->

    <!--site-main start-->
    <div class="site-main">

      <!-- about-section -->
      <section class="ttm-row about-top-section clearfix">
        <div class="container">
          <div class="row">
            <div class="col-lg-6 col-sm-12">
              <div class="position-relative pr-15 res-991-pr-0">
                <div class="row mb-30">
                  <div class="col-sm-7">
                    <!-- ttm_single_image-wrapper -->
                    <div class="ttm_single_image-wrapper ttm-991-center">
                      <img class="img-fluid" src="images/single-img-three.jpg" alt="single-img-three">
                    </div><!-- ttm_single_image-wrapper end -->
                  </div>
                  <div class="col-sm-5">
                    <!-- ttm_single_image-wrapper -->
                    <div class="ttm_single_image-wrapper ttm-991-center res-575-mt-30">
                      <img class="img-fluid" src="images/single-img-four.jpg" alt="single-img-four">
                    </div><!-- ttm_single_image-wrapper end -->
                  </div>
                </div>
                <div class="row">
                  <div class="col-lg-12">
                    <div class="position-relative">
                      <!-- ttm_single_image-wrapper -->
                      <div class="ttm_single_image-wrapper w100">
                        <img class="img-fluid" src="images/single-img-five.jpg" alt="single-img-five">
                      </div><!-- ttm_single_image-wrapper end -->
                      <!--ttm-fid-->
                      <div class="ttm-fid inside ttm-fid-view-lefticon ttm-highlight-fid-style2">
                        <div class="ttm-fid-left">
                          <div class="ttm-fid-icon-wrapper">
                            <i class="ti ti-world"></i>
                          </div>
                        </div>
                        <div class="ttm-fid-contents text-left">
                          <h4 class="ttm-fid-inner">
                            <span data-appear-animation="animateDigits" data-from="0" data-to="10" data-interval="1" data-before="" data-before-style="sup" data-after="+" data-after-style="sub">10</span>
                          </h4>
                          <h3 class="ttm-fid-title">Années d'expérience</h3>
                        </div>
                      </div><!-- ttm-fid end-->
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-sm-12">
              <div class="pl-15 res-991-pl-0 res-991-mt-30">
                <!-- section title -->
                <div class="section-title pr-60 res-991-pr-0 clearfix">
                  <div class="title-header">
                    <h5>A PROPOS DE NOUS</h5>
                  </div>
                  <div class="title-desc">
                  <p class="text-justify">Sosoyamboka.info est le Premier média de proximité en ligne. Suivez l’actualité dans tous les volets, politique, social, économique… de la République démocratique du Congo comme d’ailleurs.
                  </p>
                  </div>
                </div><!-- section title end -->
                <div class="separator">
                  <div class="sep-line dashed"></div>
                </div>
                <!--
                <div class="row no-gutters">
                  <div class="col-md-6 col-sm-6">
                    <div class="featured-icon-box style1 left-icon right-border">
                      <div class="">
                        <img src="images/about-sign.png" alt="sign">
                      </div>
                      <div class="featured-content">
                        <div class="featured-title">
                          <h5>Jhon Martin</h5>
                        </div>
                        <div class="featured-desc">
                          <p>Chairnan and founder</p>
                        </div>
                      </div>
                    </div>
                  -->
                  </div>
                  <div class="col-md-6 col-sm-6">
                    <!--featured-icon-box-->
                    <div class="featured-icon-box style1 without-icon right-border">
                      <div class="featured-content">
                        <div class="featured-title">
                          <h5>SOSO YA BOMKA </h5>
                        </div>
                        <div class="featured-desc">
                          <p>Permet tout les monde d'être a la page.</p>
                        </div>
                      </div>
                    </div><!-- featured-icon-box end-->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- about-section end -->

      <!-- services-section -->
      <section class="ttm-row ttm-bgcolor-darkgrey ttm-bg ttm-bgimage-yes bg-img1 about-services-section clearfix">
        <div class="ttm-row-wrapper-bg-layer ttm-bg-layer"></div>
        <div class="container">
          <div class="row">
            <div class="col-lg-3 col-md-2 col-sm-1"></div>
            <div class="col-lg-6 col-md-8 col-sm-10">
              <!-- section title -->
              <div class="section-title text-center with-desc clearfix">
                <div class="title-header mb-60">
                  <h5>Pourquoi nous choisir</h5>
                  <h2 class="title">Nous publions de vraies informations dans le monde</h2>
                </div>
              </div><!-- section title end -->
            </div>
            <div class="col-lg-3 col-md-2 col-sm-1"></div>
          </div>
          <div class="row">
            <div class="col-lg-12">
              <div class="row align-items-center ptb-50 res-991-ptb-20 iconalign-before-heading-row">
                <div class="col-md-4">
                  <!-- featured-icon-box -->
                  <div class="featured-icon-box iconalign-before-heading style1">
                    <div class="featured-content">
                      <!-- featured-content -->
                      <div class="ttm-icon ttm-icon_element-color-skincolor ttm-icon_element-size-lg">
                        <i class="ti ti-world"></i>
                      </div>
                      <div class="featured-title">
                        <h5 class="mb-0">Notre mission</h5>
                      </div>
                    </div><!-- featured-content -->
                  </div><!-- featured-icon-box -->
                </div>
                <div class="col-md-8">
                  <p class="mb-0 ml-30 res-767-mt-20 res-767-ml-10">Vous informer en temps réel ce qui se passer dans le pays.</p>
                </div>
              </div>
              <div class="row align-items-center ptb-50 res-991-ptb-20 iconalign-before-heading-row">
                <div class="col-md-4">
                  <!-- featured-icon-box -->
                  <div class="featured-icon-box iconalign-before-heading style1">
                    <div class="featured-content">
                      <!-- featured-content -->
                      <div class="ttm-icon ttm-icon_element-color-skincolor ttm-icon_element-size-lg">
                        <i class="ti ti-bar-chart"></i>
                      </div>
                      <div class="featured-title">
                        <h5 class="mb-0">Notre devise</h5>
                      </div>
                    </div><!-- featured-content -->
                  </div><!-- featured-icon-box -->
                </div>
                <div class="col-md-8">
                  <p class="mb-0 ml-30 res-767-mt-20 res-767-ml-10">Au cœur de l’actualité en toute impartialité.</p>
                </div>
              </div>
              <div class="row align-items-center ptb-50 res-991-ptb-20 iconalign-before-heading-row">
                <div class="col-md-4">
                  <!-- featured-icon-box -->
                  <div class="featured-icon-box iconalign-before-heading style1">
                    <div class="featured-content">
                      <!-- featured-content -->
                      <div class="ttm-icon ttm-icon_element-color-skincolor ttm-icon_element-size-lg">
                        <i class="ti ti-zip"></i>
                      </div>
                      <div class="featured-title">
                        <h5 class="mb-0">Nos strategies</h5>
                      </div>
                    </div><!-- featured-content -->
                  </div><!-- featured-icon-box -->
                </div>
                <div class="col-md-8">
                  <p class="mb-0 ml-30 res-767-mt-20 res-767-ml-10">Mettre en place les équipements technologique pour aide la population d'etre informe en temp réel.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- services-section end -->

      <!--blog-text-section-->
      <section class="ttm-row blog-text-section ttm-bgcolor-grey mt_120 res-991-mt-0 clearfix">
        <div class="container">
          <!-- row -->
          <div class="row">
            <div class="col-lg-12 col-md-12">
              <!-- section-title -->
              <div class="section-title style2 clearfix">
                <div class="title-header">
                  <h5>Nos dernieres actualites</h5>
                  <h2 class="title">Lire nos dernieres informations</h2>
                </div>
                <!--
                <div class="title-desc">Know how to pursue pleasure rationally encounter consequences that are re <br> rationally encounter consequences that are extremely painful.</div>
              -->
              </div><!-- section-title end -->
            </div>
          </div><!-- row end -->
        </div>
      </section>
      <!--blog-text-section end-->

      <!--blog-section-->
      <section class="ttm-row about-blog-section clearfix">
        <div class="container">
          <!-- row -->
          <div class="row">
            <!-- post-slide -->
            <div class="post-slide owl-carousel owl-theme owl-loaded " data-item="3" data-nav="false" data-dots="false" data-auto="false">
              <!-- featured-imagebox-post -->
              <?php 

              require('includes/db_config.php');

        $sql_pol = "SELECT * FROM tbl_news  ORDER BY infodate DESC LIMIT 6 ";
        
       //Function to return only 100 charactere
        function charlimiter($string, $limit) {
        return substr($string, 0, $limit) . (strlen($string) > $limit ? " ..." : '');
        }
       $res_pol = mysqli_query($con, $sql_pol);
       if (mysqli_num_rows($res_pol)) {
       while ( $row_pol = mysqli_fetch_assoc($res_pol)) {?>
              <div class="featured-imagebox featured-imagebox-post box-shadow">
                <div class="featured-thumbnail">
                  <img class="img-fluid" src="<?php echo $row_pol['image'];?>" alt="news">
                  <div class="featured-icon">
                    <div class="ttm-icon ttm-icon_element-fill ttm-icon_element-background-color-skincolor ttm-icon_element-size-xs">
                      <i class="ti ti-pencil"></i>
                    </div>
                  </div>
                </div>
                <div class="featured-content featured-content-post">
                  <div class="post-title featured-title">
                    <h5><a href=""><?php echo charlimiter($row_pol['title'], 60);?></a></h5>
                  </div>
                  
                  <div class="post-meta">
                    <span class="ttm-meta-line"><i class="fa fa-calendar"></i><?php echo $row_pol['infodate'];?></span>
                  </div>
                </div>
              </div>
              <!-- featured-imagebox-post end -->
              <!-- featured-imagebox-post -->
            <?php }}?>
            </div>
          </div><!-- row end-->
        </div>
      </section>
      <!--blog-section end-->

    </div>
    <!--site-main end-->
    <!-- Active link per page -->
    <script>
      element = document.getElementById('about');
      element.classList.add("active")
    </script>
    <!-- End of active link -->
    <?php 
    include_once('footer.php');
    ?>