<?php 
 require('includes/db_config.php');
 //for whatsapp desciption only
 if (isset($_GET['info'])) {
 $search_desc = $_GET['info'];
 $sql_pol = "select * from tbl_news where displayid='$search_desc'";
 $res_pol = mysqli_query($con, $sql_pol);
 while ( $row_pol = mysqli_fetch_assoc($res_pol)) {
 $desc = $row_pol['title'];
 $desc_img ="http://sosoyamboka.info/images/footer-logo.png";
 $desc_title = '';
 }
 }
 else
 {
  $desc_img ="http://sosoyamboka.info/images/footer-logo.png";
  $desc_title ='SOSO YA MBOKA';
  $desc = 'soso ya mboka donne les informations réelles et correct sur la rdc';
 } 
?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta property="og:site_name" content="SOSO YA MBOKA">
  <meta property="og:image" itemprop="image" content="<?php echo $desc_img;?>">
  <meta property="og:type" content="article" />  
  <meta name="keywords" content="soso ya mboka, rdc info, congo news, congo actualites, congo information" />
  <meta name="description" content="<?php echo $desc;?>" />
  <meta name="author" content="SOSO YA MBOKA" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
  
  <title><?php echo $desc_title;?></title> 
  
 <!-- favicon icon -->
  <link rel="shortcut icon" href="images/fav-log.png" />
  <!-- bootstrap -->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
  <!-- Manifest file path -->
  <link rel="manifest" href="css/manifest.json">
  <!-- animate -->
  <link rel="stylesheet" type="text/css" href="css/animate.css" />

  <!-- owl-carousel -->
  <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">

  <!-- fontawesome -->
  <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

  <!-- themify -->
  <link rel="stylesheet" type="text/css" href="css/themify-icons.css" />

  <!-- flaticon -->
  <link rel="stylesheet" type="text/css" href="css/flaticon.css" />

  <link rel="stylesheet" type="text/css" href="css/fontawesome.css" />
  <!-- REVOLUTION LAYERS STYLES -->

  <link rel="stylesheet" type="text/css" href="css/layers.css">

  <link rel="stylesheet" type="text/css" href="css/settings.css">

  <!-- prettyphoto -->
  <link rel="stylesheet" type="text/css" href="css/prettyPhoto.css">

  <!-- shortcodes -->
  <link rel="stylesheet" type="text/css" href="css/shortcodes.css" />

  <!-- main -->
  <link rel="stylesheet" type="text/css" href="css/main.css" />

  <!-- responsive -->
  <link rel="stylesheet" type="text/css" href="css/responsive.css" />
  <script src="https://kit.fontawesome.com/610a8f6562.js" crossorigin="anonymous"></script>
  <style>
    .card_news {
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2);
    transition: 0.3s;
    width: 100%;
    height: 385px;
    background-color: #fff;
   }

.card_news:hover {
  box-shadow: 0 8px 16px 0 rgba(0,0,0,0.2);
}
.card_news img{
  height: 195px;
}
.container_news h5{
  width: 100%;
  height: 85px;
}

#hideloader{
  display: none;
}
#messageGet{
  display: none;
  margin-left: 8px;
  font-size: 18px;
}
.container_news {
  padding: 2px 16px;
}
.container_news p{
  border-left: 4.2px #f71735 solid;
  padding-left: 3px;
  text-align: justify;
} 

#poli::first-letter {
text-transform:capitalize;
}
.politique {
 border-left: 4.2px #f71735 solid;
 padding-left: 3px; 
}
.poli a{
 color: rgba(0,0,0,.6);
}
.rightdetail{
  margin-right: 13.3%;
}

.typewriter {
    font-family: Courier, monospace;
  display: inline-block;
}

.title-ani {
    width: 100%;
    display: inline-block;
    overflow: hidden;
    letter-spacing: 2px;
  animation: typing 5s steps(30, end), blink .75s step-end infinite;
    white-space: nowrap;
    font-size: 33px !important;
    font-weight: 700;
    border-right: 4px solid orange;
    box-sizing: border-box;
}


@keyframes typing {
    from { 
        width: 0% 
    }
    to { 
        width: 100% 
    }
}

@keyframes blink {
    from, to { 
        border-color: transparent 
    }
    50% { 
        border-color: transparent; 
    }
}
#reduice{
  height: 289px;
}
</style>
</head>
